package com.zahid.bot

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.io.File
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** قراءات الحالة الفعلية (شبكة الجهاز + ملف السجل). لا ارقام او حالات مصطنعة. */
object BotStatus {

    /** هل الجهاز متصل بشبكة فيها انترنت فعلاً (تحقق النظام نفسه). */
    fun isOnline(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) {
            false
        }
    }

    fun logFile(ctx: Context) = File(ctx.filesDir, "zahid.log")

    /** آخر maxBytes من الملف كنص (يحذف السطر الاول الناقص). null اذا تعذرت القراءة. */
    fun readTail(f: File, maxBytes: Int, fromOffset: Long = 0L): String? {
        if (!f.exists()) return ""
        return try {
            RandomAccessFile(f, "r").use { raf ->
                val len = raf.length()
                val start = maxOf(len - maxBytes, if (fromOffset in 1 until len) fromOffset else 0L)
                val n = (len - start).toInt()
                if (n <= 0) return ""
                raf.seek(start)
                val buf = ByteArray(n)
                raf.readFully(buf)
                var text = String(buf, Charsets.UTF_8)
                if (start > 0) {
                    val nl = text.indexOf('\n')
                    if (nl >= 0) text = text.substring(nl + 1)
                }
                text
            }
        } catch (_: Exception) {
            null
        }
    }

    private val AUTH_ERRORS = listOf(
        "AUTH_KEY_UNREGISTERED", "SESSION_REVOKED", "SESSION_EXPIRED",
        "USER_DEACTIVATED", "AUTH_KEY_DUPLICATED", "AUTH_KEY_INVALID"
    )

    /**
     * هل ظهر في السجل ما يدل على ان تيليجرام رفض الجلسة؟
     * اثناء التشغيل نفحص ما بعد بداية هذا التشغيل فقط، وعند التوقف نفحص آخر جلسة تشغيل.
     */
    fun sessionRejected(ctx: Context, running: Boolean): Boolean {
        val tail = readTail(logFile(ctx), 64 * 1024, if (running) BotService.logStartOffset else 0L) ?: return false
        val section = if (running) tail else {
            val h = tail.lastIndexOf("=".repeat(30))
            if (h >= 0) tail.substring(h) else tail
        }
        return AUTH_ERRORS.any { section.contains(it) }
    }

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateTimeFmt = SimpleDateFormat("MM-dd HH:mm", Locale.US)

    fun clock(millis: Long): String = timeFmt.format(Date(millis))

    /** وقت قصير: اليوم = الساعة فقط، غير ذلك = التاريخ والساعة. */
    fun shortTime(millis: Long): String {
        val day = SimpleDateFormat("yyyyMMdd", Locale.US)
        return if (day.format(Date(millis)) == day.format(Date())) clock(millis)
        else dateTimeFmt.format(Date(millis))
    }
}
