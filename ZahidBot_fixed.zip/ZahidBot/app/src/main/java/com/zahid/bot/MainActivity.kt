package com.zahid.bot

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.text.Spanned
import android.text.SpannableString
import android.text.method.PasswordTransformationMethod
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import androidx.core.view.doOnLayout
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.io.RandomAccessFile
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import org.json.JSONObject

/**
 * الواجهة: اربعة تبويبات (الرئيسية / الاعدادات / السجل / حول) داخل Activity واحدة.
 * كل الصفحات موجودة دائماً ويتبدّل الظاهر فقط، فلا تضيع المدخلات عند التنقل.
 * منطق التشغيل نفسه لم يتغيّر: BotService + PyHelper + Prefs.
 */
class MainActivity : AppCompatActivity() {

    private enum class Tab { HOME, SETTINGS, LOGS, ABOUT }
    private enum class Op { NONE, STARTING, STOPPING }

    /** حالة تُعرض في بطاقة: نص + تفصيل + لون النقطة + هل هناك تحميل. */
    private data class Ui(val text: String, val detail: String, val colorRes: Int, val busy: Boolean = false)

    private val sensitiveKeys = listOf("api_hash", "session", "token")

    // ── العناصر ──
    private lateinit var fields: Map<String, TextInputEditText>
    private lateinit var layouts: Map<String, TextInputLayout>
    private lateinit var pages: Map<Tab, View>
    private lateinit var navs: Map<Tab, View>
    private lateinit var headerBlock: View
    private lateinit var tvHomeLog: TextView

    private lateinit var navBar: View
    private lateinit var scrollSettings: ScrollView
    private lateinit var settingsContent: View

    private lateinit var tvConnValue: TextView
    private lateinit var tvConnDetail: TextView
    private lateinit var dotConn: View
    private lateinit var tvBotValue: TextView
    private lateinit var tvBotDetail: TextView
    private lateinit var dotBot: View
    private lateinit var progBot: ProgressBar

    private lateinit var tvNotif: TextView
    private lateinit var tvBattery: TextView
    private lateinit var btnNotif: Button
    private lateinit var btnBattery: Button
    private lateinit var tvSessionStatus: TextView
    private lateinit var tvSessionHint: TextView
    private lateinit var tvSaveState: TextView
    private lateinit var btnSave: Button

    private lateinit var scrollLog: ScrollView
    private lateinit var tvLog: TextView
    private lateinit var tvLogEmpty: TextView
    private lateinit var swAutoScroll: SwitchMaterial
    private lateinit var swLogDetails: SwitchMaterial

    // ── الحالة ──
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var currentTab = Tab.HOME
    private var tabInitialized = false

    private var afterNotifGranted: (() -> Unit)? = null
    private var onboardingNext: (() -> Unit)? = null

    private var op = Op.NONE
    private var opStartedAt = 0L
    private var opDeadline = 0L
    private var opSeenRunning = false

    private var savedSnapshot: Map<String, String> = emptyMap()
    private var saveMsg: Pair<String, Int>? = null
    private var saving = false

    private var bgBusy = false
    private var sessionRejected = false
    private var lastLogSig: Pair<Long, Long>? = null
    private var logEntries: List<LogFormat.Entry> = emptyList()
    private val revealed = mutableSetOf<String>()

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            refresh()
            if (granted) afterNotifGranted?.invoke()
            else toast("بدون الاشعارات قد يقتل النظام البوت")
            afterNotifGranted = null
            onboardingNext?.invoke()   // يكمل خطوات اول تشغيل سواء وافق ام رفض
            onboardingNext = null
        }

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 2000)
        }
    }

    // ───────────────────────── دورة الحياة ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupHeader()
        setupNavigation()
        loadSavedValues()
        setupFields()
        setupSettingsActions()
        setupHomeActions()
        setupLogs()
        setupAbout()
        setupKeyboardInsets()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentTab != Tab.HOME) {
                    selectTab(Tab.HOME)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        val startTab = savedInstanceState?.getString("tab")?.let { name ->
            Tab.values().firstOrNull { it.name == name }
        } ?: Tab.HOME
        selectTab(startTab, animate = false)

        if (!Prefs.onboarded(this)) {
            firstRun()
        } else if (savedInstanceState == null &&
            Prefs.runOnOpen(this) && !BotService.running && Prefs.isConfigured(this)
        ) {
            startBot()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", currentTab.name)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        // القيم الحساسة تعود مخفية كلما غادر المستخدم الشاشة
        sensitiveKeys.forEach { hideSensitive(it) }
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        io.shutdown()
        super.onDestroy()
    }

    // ───────────────────────── الربط والتهيئة ─────────────────────────

    private fun bindViews() {
        fields = mapOf(
            "api_id" to findViewById<TextInputEditText>(R.id.etApiId),
            "api_hash" to findViewById<TextInputEditText>(R.id.etApiHash),
            "session" to findViewById<TextInputEditText>(R.id.etSession),
            "token" to findViewById<TextInputEditText>(R.id.etToken),
            "bot_user" to findViewById<TextInputEditText>(R.id.etBotUser),
            "sudo_id" to findViewById<TextInputEditText>(R.id.etSudoId),
        )
        layouts = mapOf(
            "api_id" to findViewById<TextInputLayout>(R.id.tilApiId),
            "api_hash" to findViewById<TextInputLayout>(R.id.tilApiHash),
            "session" to findViewById<TextInputLayout>(R.id.tilSession),
            "token" to findViewById<TextInputLayout>(R.id.tilToken),
            "bot_user" to findViewById<TextInputLayout>(R.id.tilBotUser),
            "sudo_id" to findViewById<TextInputLayout>(R.id.tilSudoId),
        )
        pages = mapOf(
            Tab.HOME to findViewById<View>(R.id.pageHome),
            Tab.SETTINGS to findViewById<View>(R.id.pageSettings),
            Tab.LOGS to findViewById<View>(R.id.pageLogs),
            Tab.ABOUT to findViewById<View>(R.id.pageAbout),
        )
        navs = mapOf(
            Tab.HOME to findViewById<View>(R.id.navHome),
            Tab.SETTINGS to findViewById<View>(R.id.navSettings),
            Tab.LOGS to findViewById<View>(R.id.navLogs),
            Tab.ABOUT to findViewById<View>(R.id.navAbout),
        )
        headerBlock = findViewById(R.id.headerBlock)
        tvHomeLog = findViewById(R.id.tvHomeLog)
        navBar = findViewById(R.id.navBar)
        scrollSettings = findViewById(R.id.scrollSettings)
        settingsContent = findViewById(R.id.settingsContent)

        tvConnValue = findViewById(R.id.tvConnValue)
        tvConnDetail = findViewById(R.id.tvConnDetail)
        dotConn = findViewById(R.id.dotConn)
        tvBotValue = findViewById(R.id.tvBotValue)
        tvBotDetail = findViewById(R.id.tvBotDetail)
        dotBot = findViewById(R.id.dotBot)
        progBot = findViewById(R.id.progBot)

        tvNotif = findViewById(R.id.tvNotif)
        tvBattery = findViewById(R.id.tvBattery)
        btnNotif = findViewById(R.id.btnNotif)
        btnBattery = findViewById(R.id.btnBattery)
        tvSessionStatus = findViewById(R.id.tvSessionStatus)
        tvSessionHint = findViewById(R.id.tvSessionHint)
        tvSaveState = findViewById(R.id.tvSaveState)
        btnSave = findViewById(R.id.btnSave)

        scrollLog = findViewById(R.id.scrollLog)
        tvLog = findViewById(R.id.tvLog)
        tvLogEmpty = findViewById(R.id.tvLogEmpty)
        swAutoScroll = findViewById(R.id.swAutoScroll)
        swLogDetails = findViewById(R.id.swLogDetails)
    }

    private fun setupHeader() {
        // TELETHON ابيض، و //ZAHID بنفسجي نيون
        val title = SpannableString("TELETHON//ZAHID")
        title.setSpan(
            ForegroundColorSpan(c(R.color.zp_neon)), 8, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        findViewById<TextView>(R.id.tvAppTitle).text = title
    }

    private fun setupNavigation() {
        navs.forEach { (tab, view) -> view.setOnClickListener { selectTab(tab) } }
        findViewById<View>(R.id.btnMenu).setOnClickListener { selectTab(Tab.SETTINGS) }
    }

    private fun selectTab(tab: Tab, animate: Boolean = true) {
        if (tabInitialized && tab == currentTab) return
        tabInitialized = true
        currentTab = tab
        Tab.values().forEach { t ->
            val page = pages.getValue(t)
            val selected = t == tab
            navs.getValue(t).isSelected = selected
            page.animate().cancel()
            if (selected) {
                page.visibility = View.VISIBLE
                if (animate) {
                    page.alpha = 0f
                    page.animate().alpha(1f).setDuration(140).start()
                } else {
                    page.alpha = 1f
                }
            } else {
                page.visibility = View.GONE
                page.alpha = 1f
            }
        }
        hideKeyboard()
        if (tab == Tab.LOGS || tab == Tab.HOME) reloadLog(force = true)
        refresh()
    }

    /** يخفي شريط التنقل اثناء ظهور لوحة المفاتيح ليبقى مكان للمحتوى. */
    private fun setupKeyboardInsets() {
        val root = findViewById<View>(R.id.root)
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val visible = Rect()
            root.getWindowVisibleDisplayFrame(visible)
            val screenH = root.rootView.height
            val keyboardOpen = screenH > 0 && (screenH - visible.bottom) > screenH * 0.15
            navBar.visibility = if (keyboardOpen) View.GONE else View.VISIBLE
            headerBlock.visibility = if (keyboardOpen) View.GONE else View.VISIBLE
        }
    }

    private fun hideKeyboard() {
        val v = currentFocus ?: return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(v.windowToken, 0)
    }

    // ───────────────────────── الاعدادات: الحقول والحفظ ─────────────────────────

    private fun loadSavedValues() {
        val saved = Prefs.FIELDS.associateWith { Prefs.get(this, it) }
        fields.forEach { (k, v) -> v.setText(saved[k]) }
        savedSnapshot = saved
        findViewById<SwitchMaterial>(R.id.swBoot).isChecked = Prefs.autoStart(this)
        findViewById<SwitchMaterial>(R.id.swRunOnOpen).isChecked = Prefs.runOnOpen(this)
        findViewById<SwitchMaterial>(R.id.swConfirmStop).isChecked = Prefs.confirmStop(this)
    }

    private fun setupFields() {
        // اي تعديل: يمسح خطأ الحقل ويحدّث حالة "غير محفوظ"
        fields.forEach { (k, et) ->
            et.doAfterTextChanged {
                layouts.getValue(k).error = null
                saveMsg = null
                updateSaveState()
            }
        }
        setupSensitive("api_hash", R.id.btnCopyApiHash, "API HASH")
        setupSensitive("session", R.id.btnCopySession, "Session String")
        setupSensitive("token", R.id.btnCopyToken, "Bot Token")
        updateSaveState()
    }

    private fun setupSensitive(key: String, copyBtnId: Int, label: String) {
        hideSensitive(key)
        layouts.getValue(key).setEndIconOnClickListener {
            if (key in revealed) hideSensitive(key)
            else confirmSensitive("عرض $label") { revealSensitive(key) }
        }
        findViewById<ImageButton>(copyBtnId).setOnClickListener {
            val text = fieldText(key)
            if (text.isEmpty()) toast("الحقل فارغ، لا يوجد ما يُنسخ")
            else confirmSensitive("نسخ $label") { copySensitive(label, text) }
        }
    }

    private fun hideSensitive(key: String) {
        val et = fields[key] ?: return
        et.transformationMethod = PasswordTransformationMethod.getInstance()
        layouts[key]?.endIconDrawable = ContextCompat.getDrawable(this, R.drawable.ic_eye)
        revealed.remove(key)
    }

    private fun revealSensitive(key: String) {
        val et = fields.getValue(key)
        et.transformationMethod = null
        layouts.getValue(key).endIconDrawable = ContextCompat.getDrawable(this, R.drawable.ic_eye_off)
        revealed.add(key)
    }

    private fun confirmSensitive(action: String, onOk: () -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("بيانات حساسة")
            .setMessage(
                "سيتم $action.\n\n" +
                "هذه القيمة تمنح صلاحية على حسابك أو بوتك. تأكد أن لا أحد يرى شاشتك، ولا تشاركها مع أحد."
            )
            .setPositiveButton("متابعة") { _, _ -> onOk() }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun copySensitive(label: String, text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        if (Build.VERSION.SDK_INT >= 33) {
            // يطلب من النظام اخفاء المحتوى في معاينة الحافظة
            clip.description.extras = PersistableBundle().apply {
                putBoolean("android.content.extra.IS_SENSITIVE", true)
            }
        }
        cm.setPrimaryClip(clip)
        if (Build.VERSION.SDK_INT < 33) toast("تم النسخ")
    }

    private fun fieldText(k: String): String = currentValues().getValue(k)

    /** القيم الحالية في الحقول؛ المفاتيح الطويلة تُنظّف من المسافات والاسطر. */
    private fun currentValues(): Map<String, String> = fields.mapValues { (k, et) ->
        val raw = et.text?.toString().orEmpty()
        if (k in sensitiveKeys) raw.filter { !it.isWhitespace() } else raw.trim()
    }

    private fun isDirty(): Boolean = currentValues() != savedSnapshot

    private fun updateSaveState() {
        val msg = saveMsg
        when {
            saving -> setSaveText("جارٍ الحفظ…", R.color.zp_lavender)
            isDirty() -> setSaveText("تغييرات غير محفوظة", R.color.zp_yellow)
            msg != null -> setSaveText(msg.first, msg.second)
            savedSnapshot.values.all { it.isEmpty() } -> setSaveText("لم تُدخل بيانات بعد", R.color.zp_dim)
            else -> setSaveText("كل البيانات محفوظة", R.color.zp_dim)
        }
    }

    private fun setSaveText(t: String, colorRes: Int) {
        tvSaveState.text = t
        tvSaveState.setTextColor(c(colorRes))
    }

    private fun showFieldErrors(errs: Map<String, String>) {
        layouts.forEach { (k, til) -> til.error = errs[k] }
    }

    /** يتحقق ثم يحفظ في خيط خلفي. onDone(true) فقط اذا كُتبت البيانات فعلاً. */
    private fun doSave(onDone: ((Boolean) -> Unit)? = null) {
        if (saving) return
        val values = currentValues()
        val errs = Prefs.validateFields(values)
        showFieldErrors(errs)
        if (errs.isNotEmpty()) {
            saveMsg = "فشل الحفظ: تحقق من الحقول المعلّمة" to R.color.zp_red
            updateSaveState()
            toast(errs.values.first())
            focusFirstError(errs)
            onDone?.invoke(false)
            return
        }
        saving = true
        btnSave.isEnabled = false
        updateSaveState()
        io.execute {
            val ok = try { Prefs.save(this, values) } catch (_: Exception) { false }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                saving = false
                btnSave.isEnabled = true
                if (ok) {
                    savedSnapshot = values
                    saveMsg = "تم الحفظ ✓" to R.color.zp_green
                    toast("تم الحفظ")
                } else {
                    saveMsg = "فشل الحفظ: تعذّرت الكتابة في التخزين الآمن" to R.color.zp_red
                    toast("فشل الحفظ — البيانات ما زالت في الحقول، حاول مرة أخرى")
                }
                updateSaveState()
                onDone?.invoke(ok)
            }
        }
    }

    private fun focusFirstError(errs: Map<String, String>) {
        val key = Prefs.FIELDS.firstOrNull { errs.containsKey(it) } ?: return
        selectTab(Tab.SETTINGS, animate = false)
        val til = layouts.getValue(key)
        scrollSettings.doOnLayout { sv ->
            (sv as ScrollView).smoothScrollTo(0, (offsetTop(til, settingsContent) - dp(24)).coerceAtLeast(0))
        }
        fields.getValue(key).requestFocus()
    }

    // ───────────────────────── الاعدادات: الازرار والخيارات ─────────────────────────

    private fun setupSettingsActions() {
        btnSave.setOnClickListener { doSave() }
        btnNotif.setOnClickListener { requestNotifications(null) }
        btnBattery.setOnClickListener { requestBatteryExemption() }
        findViewById<Button>(R.id.btnAppSettings).setOnClickListener { openAppSettings() }

        findViewById<SwitchMaterial>(R.id.swBoot)
            .setOnCheckedChangeListener { _, on -> Prefs.setAutoStart(this, on) }
        findViewById<SwitchMaterial>(R.id.swRunOnOpen)
            .setOnCheckedChangeListener { _, on -> Prefs.setRunOnOpen(this, on) }
        findViewById<SwitchMaterial>(R.id.swConfirmStop)
            .setOnCheckedChangeListener { _, on -> Prefs.setConfirmStop(this, on) }

        findViewById<Button>(R.id.btnHelpApi).setOnClickListener { showApiHelp() }
        findViewById<Button>(R.id.btnGetSession).setOnClickListener { extractSession() }
        findViewById<Button>(R.id.btnMakeBot).setOnClickListener { makeBot() }
        findViewById<Button>(R.id.btnFetchBot).setOnClickListener { fetchBotUser() }
    }

    // ───────────────────────── الرئيسية ─────────────────────────

    private fun setupHomeActions() {
        // بطاقة حالة البوت = مفتاح تشغيل/إيقاف (التصميم لا يحتوي ازرار منفصلة)
        findViewById<View>(R.id.statusBot).setOnClickListener {
            if (BotService.running) requestStop() else startBot()
        }
        findViewById<View>(R.id.btnHomeLogClear).setOnClickListener { confirmClearLog() }
        findViewById<View>(R.id.cardAppInfo).setOnClickListener { selectTab(Tab.ABOUT) }

        fun tile(tileId: Int, cardId: Int) =
            findViewById<View>(tileId).setOnClickListener { goToSettingsCard(cardId) }
        tile(R.id.tileAccount, R.id.cardAccount)
        tile(R.id.tileBot, R.id.cardBot)
        tile(R.id.tilePerms, R.id.cardPerms)
        tile(R.id.tileSession, R.id.cardSession)
        tile(R.id.tileOptions, R.id.cardOptions)
    }

    private fun goToSettingsCard(cardId: Int) {
        selectTab(Tab.SETTINGS)
        val card = findViewById<View>(cardId)
        scrollSettings.doOnLayout { sv ->
            (sv as ScrollView).smoothScrollTo(0, offsetTop(card, settingsContent))
        }
    }

    private fun offsetTop(v: View, ancestor: View): Int {
        var y = 0
        var cur: View = v
        while (cur !== ancestor) {
            y += cur.top
            cur = cur.parent as? View ?: break
        }
        return y
    }

    // ───────────────────────── التشغيل والايقاف ─────────────────────────

    private fun startBot() {
        if (op != Op.NONE || BotService.running) return
        val values = currentValues()
        val errs = Prefs.validateFields(values)
        if (errs.isNotEmpty()) {
            showFieldErrors(errs)
            toast(errs.values.first())
            focusFirstError(errs)
            return
        }
        val go = { requestNotifications { launchService() } }
        if (values == savedSnapshot) go() else doSave { ok -> if (ok) go() }
    }

    private fun launchService() {
        if (op != Op.NONE || BotService.running) return
        op = Op.STARTING
        opStartedAt = System.currentTimeMillis()
        opDeadline = opStartedAt + 90_000
        opSeenRunning = false
        try {
            ContextCompat.startForegroundService(this, Intent(this, BotService::class.java))
        } catch (e: Exception) {
            op = Op.NONE
            toast("تعذّر بدء الخدمة: ${e.javaClass.simpleName}")
        }
        refresh()
    }

    private fun requestStop() {
        if (!BotService.running || op == Op.STOPPING) return
        if (Prefs.confirmStop(this)) {
            AlertDialog.Builder(this)
                .setTitle("إيقاف البوت")
                .setMessage("هل تريد إيقاف البوت؟ ستتوقف كل أوامره حتى تشغّله مرة أخرى.")
                .setPositiveButton("إيقاف") { _, _ -> doStop() }
                .setNegativeButton("إلغاء", null)
                .show()
        } else {
            doStop()
        }
    }

    private fun doStop() {
        if (!BotService.running || op == Op.STOPPING) return
        op = Op.STOPPING
        opStartedAt = System.currentTimeMillis()
        opDeadline = opStartedAt + 20_000
        startService(Intent(this, BotService::class.java).setAction(BotService.ACTION_STOP))
        refresh()
    }

    /** نتيجة العملية الجارية: لا يُعلن نجاح او فشل الا بناءً على حالة الخدمة الفعلية. */
    private fun evaluateOp(now: Long) {
        when (op) {
            Op.STARTING -> {
                if (BotService.running) opSeenRunning = true
                when {
                    BotService.connected -> {
                        op = Op.NONE
                        toast("تم تشغيل البوت والاتصال بتيليجرام")
                    }
                    opSeenRunning && !BotService.running -> {
                        op = Op.NONE
                        toast("فشل التشغيل — راجع تبويب السجل")
                    }
                    !opSeenRunning && now - opStartedAt > 10_000 -> {
                        op = Op.NONE
                        toast("لم تبدأ الخدمة. جرّب مرة أخرى")
                    }
                    now > opDeadline -> {
                        op = Op.NONE
                        toast("التشغيل استغرق وقتاً أطول من المعتاد — راجع السجل")
                    }
                }
            }
            Op.STOPPING -> when {
                !BotService.running -> {
                    op = Op.NONE
                    toast("تم إيقاف البوت")
                }
                now > opDeadline -> {
                    op = Op.NONE
                    toast("تعذّر الإيقاف — حاول مرة أخرى")
                }
            }
            Op.NONE -> {}
        }
    }

    // ───────────────────────── اول تشغيل والصلاحيات ─────────────────────────

    private fun firstRun() {
        AlertDialog.Builder(this)
            .setTitle("اهلاً بك")
            .setMessage(
                "لتشغيل البوت يحتاج التطبيق:\n\n" +
                "١) بيانات حسابك (API ID/HASH، الجلسة، توكن البوت، يوزر البوت، ايدي المالك)\n" +
                "٢) السماح بالاشعارات (لابقاء البوت شغالاً في الخلفية)\n" +
                "٣) الغاء قيود البطارية عن التطبيق\n\n" +
                "سنطلب الصلاحيات الآن، ثم املأ البيانات في تبويب الإعدادات واضغط حفظ."
            )
            .setCancelable(false)
            .setPositiveButton("متابعة") { _, _ ->
                if (notifGranted()) {
                    askBatteryThenFinish()
                } else {
                    onboardingNext = { askBatteryThenFinish() }
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            .show()
    }

    private fun askBatteryThenFinish() {
        Prefs.setOnboarded(this, true)
        if (!isBatteryExempt()) requestBatteryExemption()
    }

    private fun notifGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestNotifications(then: (() -> Unit)?) {
        if (notifGranted()) { then?.invoke(); return }
        afterNotifGranted = then
        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    private fun isBatteryExempt(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    @SuppressLint("BatteryLife")
    private fun requestBatteryExemption() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                toast("افتح إعدادات البطارية للتطبيق من إعدادات الهاتف")
            }
        }
    }

    private fun openAppSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            toast("تعذّر فتح إعدادات التطبيق")
        }
    }

    // ───────────────────────── استخراج المتطلبات من داخل التطبيق ─────────────────────────

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun busy(msg: String): AlertDialog =
        AlertDialog.Builder(this).setMessage(msg).setCancelable(false).create().also { it.show() }

    /** ينفّذ work في خيط خلفي مع نافذة انتظار، ثم يستدعي done في الواجهة. */
    private fun runBg(msg: String, work: () -> JSONObject, done: (JSONObject) -> Unit) {
        val d = busy(msg)
        thread(name = "zahid-helper") {
            val r = try {
                work()
            } catch (e: Throwable) {
                JSONObject().put("ok", false).put("msg", e.message ?: e.toString())
            }
            runOnUiThread {
                try { d.dismiss() } catch (_: Exception) {}
                done(r)
            }
        }
    }

    private fun askText(title: String, hint: String, inputType: Int, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            this.hint = hint
            this.inputType = inputType
            setSingleLine()
        }
        val pad = dp(16)
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("متابعة") { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton("الغاء", null)
            .show()
    }

    private fun showApiHelp() {
        AlertDialog.Builder(this)
            .setTitle("API ID و API HASH")
            .setMessage(
                "تيليجرام يعطيها من موقعه الرسمي ولا يمكن استخراجها تلقائياً:\n\n" +
                "١) افتح my.telegram.org وسجّل دخول برقمك\n" +
                "٢) اختر API development tools\n" +
                "٣) املأ اسم وعنوان قصير لأي تطبيق ثم Create\n" +
                "٤) انسخ App api_id و App api_hash الى الحقول هنا"
            )
            .setPositiveButton("فتح الموقع") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://my.telegram.org")))
                } catch (e: Exception) { toast("افتح my.telegram.org من المتصفح") }
            }
            .setNegativeButton("اغلاق", null)
            .show()
    }

    private fun apiPair(): Pair<Int, String>? {
        val id = fieldText("api_id")
        val hash = fieldText("api_hash")
        if (id.isEmpty() || !id.all { it.isDigit() } || id.length > 9 || hash.length < 20) {
            toast("املأ API ID و API HASH اولاً")
            return null
        }
        return Pair(id.toInt(), hash)
    }

    private fun extractSession() {
        val (id, hash) = apiPair() ?: return
        askText("رقم هاتفك", "مع رمز الدولة مثل +9647701234567", InputType.TYPE_CLASS_PHONE) { phone ->
            runBg("جاري طلب الكود ...", { PyHelper.call(this, "send_code", id, hash, phone) }) { r ->
                if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@runBg }
                askText("الكود", "الكود الذي وصلك في تيليجرام", InputType.TYPE_CLASS_NUMBER) { code ->
                    runBg("جاري التحقق ...", { PyHelper.call(this, "sign_in", code) }) { afterLogin(it) }
                }
            }
        }
    }

    private fun afterLogin(r: JSONObject) {
        if (!r.optBoolean("ok")) { toast(r.optString("msg")); return }
        if (r.optBoolean("need_password")) {
            askText(
                "كلمة سر التحقق بخطوتين", "كلمة السر",
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            ) { pw ->
                runBg("جاري التحقق ...", { PyHelper.call(this, "check_password", pw) }) { afterLogin(it) }
            }
            return
        }
        fields.getValue("session").setText(r.optString("session"))
        fields.getValue("sudo_id").setText(r.optLong("user_id").toString())
        toast("تم استخراج الجلسة وايدي المالك ✅ — اضغط حفظ")
    }

    private fun makeBot() {
        val (id, hash) = apiPair() ?: return
        val session = fieldText("session")
        if (session.length < 50) { toast("استخرج الجلسة اولاً"); return }
        askText("اسم البوت", "مثال: بوت زاهد", InputType.TYPE_CLASS_TEXT) { name ->
            askText("يوزر البوت", "ينتهي بـ bot مثل zahid_bot", InputType.TYPE_CLASS_TEXT) { user ->
                val u = user.removePrefix("@")
                if (!Regex("^[A-Za-z][A-Za-z0-9_]{3,30}[Bb]ot$").matches(u)) {
                    toast("اليوزر لازم يكون انجليزي وينتهي بـ bot")
                    return@askText
                }
                runBg("جاري انشاء البوت عبر BotFather (قد يأخذ نصف دقيقة) ...",
                    { PyHelper.call(this, "create_bot", session, id, hash, name, u) }) { r ->
                    if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@runBg }
                    fields.getValue("token").setText(r.optString("token"))
                    fields.getValue("bot_user").setText(r.optString("bot_user"))
                    toast("تم انشاء البوت ✅ — اضغط حفظ")
                }
            }
        }
    }

    private fun fetchBotUser() {
        val token = fieldText("token")
        if (token.isEmpty()) { toast("الصق التوكن في حقله اولاً"); return }
        runBg("جاري الجلب ...", { PyHelper.call(this, "fetch_bot", token) }) { r ->
            if (!r.optBoolean("ok")) { toast(r.optString("msg")); return@runBg }
            fields.getValue("bot_user").setText(r.optString("bot_user"))
            toast("تم جلب اليوزر ✅")
        }
    }

    // ───────────────────────── السجل ─────────────────────────

    private fun setupLogs() {
        findViewById<TextView>(R.id.tvLogLegend).text = LogFormat.legend(this)
        renderLog()   // يظهر الـ Empty State حتى تصل اول الاحداث
        swLogDetails.setOnCheckedChangeListener { _, _ -> renderLog() }

        findViewById<ImageButton>(R.id.btnLogLatest).setOnClickListener {
            scrollLog.fullScroll(View.FOCUS_DOWN)
        }
        findViewById<ImageButton>(R.id.btnLogCopy).setOnClickListener { copyLog() }
        findViewById<ImageButton>(R.id.btnLogClear).setOnClickListener { confirmClearLog() }
    }

    private fun confirmClearLog() {
        AlertDialog.Builder(this)
            .setTitle("مسح السجل")
            .setMessage("سيتم حذف كل الأحداث المسجلة، ولا يمكن استرجاعها.")
            .setPositiveButton("مسح") { _, _ -> clearLog() }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    /** معاينة السجل في الرئيسية (الأحدث اولاً). */
    private fun renderHomeLog() {
        val sp = LogFormat.toHome(this, logEntries)
        if (sp.isEmpty()) {
            tvHomeLog.setTextColor(c(R.color.zp_dim))
            tvHomeLog.text = "لا توجد أحداث بعد"
        } else {
            tvHomeLog.text = sp
        }
    }

    /** الاسرار الحالية (المحفوظة + المكتوبة في الحقول) لحجبها من اي نص يُعرض. */
    private fun secretValues(): List<String> {
        val out = mutableListOf<String>()
        sensitiveKeys.forEach { k ->
            out += Prefs.get(this, k)
            out += currentValues().getValue(k)
        }
        return out.filter { it.length >= 8 }.distinct()
    }

    /** يقرأ ويحلّل ويحجب السجل في خيط خلفي، ثم يعرضه. يتجاهل الاستدعاء اذا لم يتغير الملف. */
    private fun reloadLog(force: Boolean) {
        if (force) lastLogSig = null
        scheduleBackground()
    }

    private fun renderLog() {
        renderHomeLog()
        val details = swLogDetails.isChecked
        val shown = if (details) logEntries else logEntries.filter { !it.isDetail }
        if (shown.isEmpty()) {
            tvLog.text = ""
            scrollLog.visibility = View.GONE
            tvLogEmpty.visibility = View.VISIBLE
            return
        }
        tvLogEmpty.visibility = View.GONE
        scrollLog.visibility = View.VISIBLE
        tvLog.text = LogFormat.toSpannable(this, logEntries, details)
        if (swAutoScroll.isChecked) {
            tvLog.doOnLayout { scrollLog.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun copyLog() {
        val details = swLogDetails.isChecked
        val text = LogFormat.toPlain(logEntries, details)
        if (text.isBlank()) { toast("السجل فارغ"); return }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("zahid-log", text))
        if (Build.VERSION.SDK_INT < 33) toast("تم نسخ السجل (الاسرار محجوبة)")
    }

    private fun clearLog() {
        io.execute {
            val ok = try {
                val f = BotStatus.logFile(this)
                if (f.exists()) RandomAccessFile(f, "rw").use { it.setLength(0) }
                true
            } catch (_: Exception) { false }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                if (ok) {
                    logEntries = emptyList()
                    lastLogSig = null
                    renderLog()
                    toast("تم مسح السجل")
                } else {
                    toast("تعذّر مسح السجل")
                }
            }
        }
    }

    // ───────────────────────── حول ─────────────────────────

    private fun setupAbout() {
        val version = try {
            val info = packageManager.getPackageInfo(packageName, 0)
            "الإصدار ${info.versionName ?: "?"} (${PackageInfoCompat.getLongVersionCode(info)})"
        } catch (_: Exception) { "الإصدار غير معروف" }
        findViewById<TextView>(R.id.tvVersion).text = version
        val vName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (_: Exception) { "?" }
        findViewById<TextView>(R.id.tvHomeVersion).text = "إصدار التطبيق: $vName"
        // مأخوذة من ملفات المشروع (app/build.gradle.kts)
        findViewById<TextView>(R.id.tvLibs).text =
            "• Chaquopy — Python 3.11 على أندرويد\n" +
            "• Pyrogram — عميل Telegram\n" +
            "• fakeredis — تخزين مؤقت داخل الذاكرة\n" +
            "• Material Components for Android\n" +
            "• AndroidX AppCompat / Core KTX\n" +
            "• AndroidX Security Crypto — تشفير بيانات الحساب"
    }

    // ───────────────────────── تحديث الواجهة ─────────────────────────

    private fun c(id: Int) = ContextCompat.getColor(this, id)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** لون القيمة الكبيرة = لون النقطة، والرمادي يصبح خافتاً مقروءاً. */
    private fun valueColor(dotRes: Int) = if (dotRes == R.color.zp_debug) R.color.zp_dim else dotRes

    private fun setDot(v: View, colorRes: Int) {
        v.backgroundTintList = ColorStateList.valueOf(c(colorRes))
    }

    private fun refresh() {
        val now = System.currentTimeMillis()
        evaluateOp(now)

        val running = BotService.running
        val connected = running && BotService.connected
        val online = BotStatus.isOnline(this)
        val lastOp = Prefs.lastOp(this)

        // ── حالة الاتصال: "Online" فقط بعد تأكيد فعلي من بايثون + وجود انترنت ──
        val conn = when {
            !running -> Ui("Offline", "البوت متوقف", R.color.zp_debug)
            !connected -> Ui("Connecting", "يتم تسجيل الدخول والاتصال بتيليجرام…", R.color.zp_neon, true)
            !online -> Ui("Offline", "لا يوجد اتصال بالإنترنت على الجهاز", R.color.zp_yellow)
            else -> Ui("Online", "تم تسجيل دخول الحساب والبوت بنجاح", R.color.zp_green)
        }
        tvConnValue.text = conn.text
        tvConnValue.setTextColor(c(valueColor(conn.colorRes)))
        tvConnDetail.text = conn.detail
        setDot(dotConn, conn.colorRes)

        // ── حالة البوت ──
        val failedLast = lastOp != null && lastOp.name == "تشغيل" && !lastOp.ok
        val bot = when {
            op == Op.STOPPING -> Ui("Stopping", "يتم إنهاء الخدمة…", R.color.zp_neon, true)
            running && connected -> Ui("Active", "الخدمة تعمل في الخلفية", R.color.zp_active)
            running || op == Op.STARTING ->
                Ui("Starting", "يتم تشغيل الخدمة وتحميل الإضافات…", R.color.zp_neon, true)
            failedLast -> Ui("Stopped", "فشل آخر تشغيل — راجع تبويب السجل", R.color.zp_red)
            else -> Ui("Stopped", "اضغط لبدء البوت", R.color.zp_debug)
        }
        tvBotValue.text = bot.text
        tvBotValue.setTextColor(c(valueColor(bot.colorRes)))
        tvBotDetail.text = bot.detail
        setDot(dotBot, bot.colorRes)
        progBot.visibility = if (bot.busy) View.VISIBLE else View.GONE
        findViewById<View>(R.id.statusBot).contentDescription =
            "حالة البوت: ${bot.text}. اضغط للتشغيل أو الإيقاف. ${bot.detail}"

        // ── الصلاحيات ──
        val notif = notifGranted()
        tvNotif.text = if (notif) "● مسموحة" else "○ غير مسموحة"
        tvNotif.setTextColor(c(if (notif) R.color.zp_green else R.color.zp_yellow))
        btnNotif.isEnabled = !notif
        val bat = isBatteryExempt()
        tvBattery.text = if (bat) "● القيود ملغاة" else "○ القيود مفعّلة (قد يوقف النظام البوت)"
        tvBattery.setTextColor(c(if (bat) R.color.zp_green else R.color.zp_yellow))
        btnBattery.isEnabled = !bat

        updateSessionCard(running, connected)
        if (!saving) updateSaveState()
        scheduleBackground()
    }

    private fun updateSessionCard(running: Boolean, connected: Boolean) {
        val saved = savedSnapshot["session"].orEmpty()
        val ui = when {
            saved.length < 50 -> Ui(
                "لا توجد جلسة محفوظة",
                "استخرج جلسة جديدة أو الصق Session String في بيانات الحساب ثم احفظ.",
                R.color.zp_yellow
            )
            sessionRejected -> Ui(
                "الجلسة مرفوضة — أعد تسجيل الدخول",
                "رفض تيليجرام هذه الجلسة. استخرج جلسة جديدة ثم احفظ وأعد التشغيل.",
                R.color.zp_red
            )
            running && connected -> Ui("نشطة — تم الاتصال بنجاح", "", R.color.zp_green)
            else -> Ui(
                "محفوظة",
                "لم يُتحقق من صلاحيتها بعد؛ يحدث ذلك عند تشغيل البوت.",
                R.color.zp_lavender
            )
        }
        tvSessionStatus.text = ui.text
        tvSessionStatus.setTextColor(c(ui.colorRes))
        tvSessionHint.text = ui.detail
        tvSessionHint.visibility = if (ui.detail.isEmpty()) View.GONE else View.VISIBLE
    }

    /** اعمال قراءة الملفات (السجل / فحص الجلسة) خارج خيط الواجهة. */
    private fun scheduleBackground() {
        if (bgBusy || io.isShutdown) return
        val tab = currentTab
        if (tab != Tab.LOGS && tab != Tab.SETTINGS && tab != Tab.HOME) return
        bgBusy = true
        val running = BotService.running
        val secrets = if (tab == Tab.LOGS || tab == Tab.HOME) secretValues() else emptyList()
        val sigBefore = lastLogSig
        try {
            io.execute {
                var rejected: Boolean? = null
                var newEntries: List<LogFormat.Entry>? = null
                var newSig: Pair<Long, Long>? = null
                try {
                    if (tab == Tab.SETTINGS) {
                        rejected = BotStatus.sessionRejected(this, running)
                    } else {
                        val f = BotStatus.logFile(this)
                        val sig = if (f.exists()) f.length() to f.lastModified() else (0L to 0L)
                        if (sig != sigBefore) {
                            val raw = BotStatus.readTail(f, 48 * 1024)
                            if (raw != null) {
                                newEntries = LogFormat.parse(LogFormat.redact(raw, secrets))
                                newSig = sig
                            }
                        }
                    }
                } catch (_: Exception) {
                    // قراءة السجل فشلت: نبقي العرض السابق ولا نوقف التطبيق
                }
                runOnUiThread {
                    bgBusy = false
                    if (isDestroyed) return@runOnUiThread
                    rejected?.let { sessionRejected = it }
                    if (newEntries != null) {
                        logEntries = newEntries
                        lastLogSig = newSig
                        renderLog()
                    }
                }
            }
        } catch (_: Exception) {
            bgBusy = false
        }
    }
}
