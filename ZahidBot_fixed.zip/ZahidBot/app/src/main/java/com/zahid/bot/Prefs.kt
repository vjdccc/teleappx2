package com.zahid.bot

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

/** بيانات الحساب مشفّرة (Android Keystore)، وحالة التشغيل والخيارات في ملف عادي. */
object Prefs {
    val FIELDS = listOf("api_id", "api_hash", "session", "token", "bot_user", "sudo_id")

    @Volatile private var secureCache: SharedPreferences? = null

    private fun secure(c: Context): SharedPreferences {
        secureCache?.let { return it }
        return synchronized(this) {
            secureCache ?: run {
                val app = c.applicationContext
                val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
                EncryptedSharedPreferences.create(
                    app, "zahid_secure", key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            }.also { secureCache = it }
        }
    }

    private fun state(c: Context): SharedPreferences =
        c.getSharedPreferences("zahid_state", Context.MODE_PRIVATE)

    fun get(c: Context, k: String): String = secure(c).getString(k, "") ?: ""

    /** يرجع true فقط اذا كُتبت البيانات فعلاً (commit متزامن). */
    fun save(c: Context, values: Map<String, String>): Boolean {
        val e = secure(c).edit()
        values.forEach { (k, v) -> e.putString(k, v.trim()) }
        return e.commit()
    }

    /** اخطاء كل حقل على حدة (المفتاح = اسم الحقل). فارغة اذا كانت البيانات سليمة. */
    fun validateFields(v: Map<String, String>): Map<String, String> {
        val errors = LinkedHashMap<String, String>()
        val apiId = v["api_id"].orEmpty().trim()
        if (apiId.isEmpty() || !apiId.all { it.isDigit() }) errors["api_id"] = "API ID يجب ان يكون ارقاماً فقط"
        if (v["api_hash"].orEmpty().trim().length < 20) errors["api_hash"] = "API HASH غير صحيح"
        if (v["session"].orEmpty().trim().length < 50) errors["session"] = "Session String غير صحيح (قصير جداً)"
        if (!Regex("^\\d+:[A-Za-z0-9_-]{20,}$").matches(v["token"].orEmpty().trim())) errors["token"] = "Bot Token غير صحيح"
        val bu = v["bot_user"].orEmpty().trim()
        if (bu.isEmpty() || bu.startsWith("@") || bu.contains(" ")) errors["bot_user"] = "يوزر البوت يكتب بدون @ وبدون مسافات"
        val sudo = v["sudo_id"].orEmpty().trim()
        if (sudo.isEmpty() || !sudo.all { it.isDigit() }) errors["sudo_id"] = "ايدي المالك يجب ان يكون ارقاماً فقط"
        return errors
    }

    /** يرجع نص الخطأ بالعربي او null اذا كانت البيانات سليمة. */
    fun validate(v: Map<String, String>): String? = validateFields(v).values.firstOrNull()

    fun toJson(c: Context): String {
        val o = JSONObject()
        FIELDS.forEach { o.put(it, get(c, it)) }
        return o.toString()
    }

    fun isConfigured(c: Context): Boolean = validate(FIELDS.associateWith { get(c, it) }) == null

    fun onboarded(c: Context): Boolean = state(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) = state(c).edit().putBoolean("onboarded", v).apply()

    fun wantRunning(c: Context): Boolean = state(c).getBoolean("want_running", false)
    fun setWantRunning(c: Context, v: Boolean) = state(c).edit().putBoolean("want_running", v).apply()

    fun autoStart(c: Context): Boolean = state(c).getBoolean("auto_start", false)
    fun setAutoStart(c: Context, v: Boolean) = state(c).edit().putBoolean("auto_start", v).apply()

    /** تشغيل البوت عند فتح التطبيق (افتراضياً مغلق). */
    fun runOnOpen(c: Context): Boolean = state(c).getBoolean("run_on_open", false)
    fun setRunOnOpen(c: Context, v: Boolean) = state(c).edit().putBoolean("run_on_open", v).apply()

    /** نافذة تأكيد قبل الايقاف (افتراضياً مفعّلة). */
    fun confirmStop(c: Context): Boolean = state(c).getBoolean("confirm_stop", true)
    fun setConfirmStop(c: Context, v: Boolean) = state(c).edit().putBoolean("confirm_stop", v).apply()

    // آخر عملية تشغيل/ايقاف ونتيجتها الفعلية (تكتبها الخدمة عند حدوث النتيجة)
    fun setLastOp(c: Context, name: String, ok: Boolean) {
        state(c).edit()
            .putString("last_op_name", name)
            .putBoolean("last_op_ok", ok)
            .putLong("last_op_time", System.currentTimeMillis())
            .apply()
    }

    data class LastOp(val name: String, val ok: Boolean, val timeMillis: Long)

    fun lastOp(c: Context): LastOp? {
        val s = state(c)
        val name = s.getString("last_op_name", null) ?: return null
        return LastOp(name, s.getBoolean("last_op_ok", true), s.getLong("last_op_time", 0L))
    }
}
