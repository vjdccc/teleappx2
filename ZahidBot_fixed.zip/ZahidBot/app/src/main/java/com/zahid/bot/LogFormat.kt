package com.zahid.bot

import android.content.Context
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.core.content.ContextCompat

/** تحليل ملف السجل (نص بايثون) الى احداث ملونة، مع حجب الاسرار. */
object LogFormat {

    enum class Level(val tag: String, val colorRes: Int) {
        INFO("INFO", R.color.zp_info),
        SUCCESS("SUCCESS", R.color.zp_green),
        WARNING("WARNING", R.color.zp_yellow),
        ERROR("ERROR", R.color.zp_red),
        DEBUG("DEBUG", R.color.zp_debug),
    }

    /** isDetail = سطر تقني (Traceback) يظهر فقط عند تفعيل "تفاصيل تقنية". */
    data class Entry(val time: String, val level: Level, val text: String, val isDetail: Boolean)

    private val TS = Regex("^(\\d{2}:\\d{2}:\\d{2}) (.*)$")
    private val ERROR_RE = Regex("traceback|exception|\\berror\\b|خطأ|فشل|failed|crash|critical", RegexOption.IGNORE_CASE)
    private val WARN_RE = Regex("warn|تحذير|flood|retry|timeout|انتهت المهلة", RegexOption.IGNORE_CASE)
    private val OK_RE = Regex("✅|success|نجح|^تم |شغّال|شغال", RegexOption.IGNORE_CASE)
    private val DEBUG_RE = Regex("debug", RegexOption.IGNORE_CASE)

    private val TOKEN_RE = Regex("\\b\\d{6,}:[A-Za-z0-9_-]{30,}")
    private val LONG_RE = Regex("[A-Za-z0-9_+/=-]{120,}")

    /** يحجب الاسرار المعروفة + اي توكن بوت + اي سلسلة طويلة تشبه الجلسة. */
    fun redact(text: String, secrets: List<String>): String {
        var t = text
        for (s in secrets) if (s.length >= 8) t = t.replace(s, "***")
        t = TOKEN_RE.replace(t, "***")
        t = LONG_RE.replace(t, "***")
        return t
    }

    fun parse(raw: String): List<Entry> {
        val out = ArrayList<Entry>()
        var inTraceback = false
        for (line in raw.lineSequence()) {
            if (line.isBlank()) continue
            val m = TS.matchEntire(line)
            val time = m?.groupValues?.get(1) ?: "--:--:--"
            val body = (m?.groupValues?.get(2) ?: line).trimEnd()

            when {
                body.startsWith("==========") -> {
                    inTraceback = false
                    val date = body.trimStart('=').trim()
                    out += Entry(time, Level.DEBUG, "── جلسة تشغيل جديدة $date ──", false)
                }
                body.startsWith("Traceback (most recent call last)") -> {
                    inTraceback = true
                    out += Entry(time, Level.ERROR, body, true)
                }
                inTraceback && (body.startsWith(" ") || body.startsWith("\t")) ->
                    out += Entry(time, Level.ERROR, body, true)
                inTraceback -> {
                    // السطر الاخير من Traceback = رسالة الخطأ نفسها (تظهر دائماً)
                    inTraceback = false
                    out += Entry(time, Level.ERROR, body, false)
                }
                body.startsWith("During handling of the above exception") ||
                    body.startsWith("The above exception was the direct cause") ->
                    out += Entry(time, Level.ERROR, body, true)
                else -> out += Entry(time, classify(body), body, false)
            }
        }
        return out
    }

    private fun classify(body: String): Level = when {
        ERROR_RE.containsMatchIn(body) -> Level.ERROR
        WARN_RE.containsMatchIn(body) -> Level.WARNING
        OK_RE.containsMatchIn(body) -> Level.SUCCESS
        DEBUG_RE.containsMatchIn(body) -> Level.DEBUG
        else -> Level.INFO
    }

    private fun visible(entries: List<Entry>, showDetails: Boolean) =
        if (showDetails) entries else entries.filter { !it.isDetail }

    /** نص عادي للنسخ (يطابق ما يُعرض). */
    fun toPlain(entries: List<Entry>, showDetails: Boolean): String =
        visible(entries, showDetails).joinToString("\n") {
            if (it.isDetail) "${it.time}            ${it.text}" else "${it.time}  [${it.level.tag}] ${it.text}"
        }

    fun toSpannable(ctx: Context, entries: List<Entry>, showDetails: Boolean): SpannableStringBuilder {
        val dim = ContextCompat.getColor(ctx, R.color.zp_dim)
        val textColor = ContextCompat.getColor(ctx, R.color.zp_text)
        val sb = SpannableStringBuilder()
        for (e in visible(entries, showDetails)) {
            val lvl = ContextCompat.getColor(ctx, e.level.colorRes)
            append(sb, e.time + "  ", dim, false)
            if (e.isDetail) {
                append(sb, " ".repeat(10), dim, false)
                append(sb, e.text + "\n", dim, false)
            } else {
                append(sb, ("[" + e.level.tag + "]").padEnd(10), lvl, true)
                val msgColor = when (e.level) {
                    Level.ERROR, Level.WARNING -> lvl
                    Level.DEBUG -> dim
                    else -> textColor
                }
                append(sb, e.text + "\n", msgColor, false)
            }
        }
        return sb
    }


    /** معاينة مختصرة لبطاقة "سجل النظام" في الرئيسية: الأحدث اولاً، سطر لكل حدث. */
    fun toHome(ctx: Context, entries: List<Entry>, max: Int = 30): SpannableStringBuilder {
        val timeColor = ContextCompat.getColor(ctx, R.color.zp_log_time)
        val sb = SpannableStringBuilder()
        val list = entries.filter { !it.isDetail }.takeLast(max).asReversed()
        list.forEachIndexed { i, e ->
            val lvl = ContextCompat.getColor(ctx, e.level.colorRes)
            val icon = when (e.level) {
                Level.SUCCESS -> "\u2705"
                Level.INFO -> "\u2139\uFE0F"
                Level.WARNING -> "\u26A0\uFE0F"
                Level.ERROR -> "\u274C"
                Level.DEBUG -> "\u2022"
            }
            append(sb, "[ " + e.time + " ] ", timeColor, false)
            append(sb, icon + " ", lvl, false)
            append(sb, e.text + (if (i < list.lastIndex) "\n" else ""), lvl, false)
        }
        return sb
    }

    fun legend(ctx: Context): SpannableStringBuilder {
        val sb = SpannableStringBuilder()
        Level.values().forEachIndexed { i, l ->
            if (i > 0) append(sb, "  ·  ", ContextCompat.getColor(ctx, R.color.zp_dim), false)
            append(sb, l.tag, ContextCompat.getColor(ctx, l.colorRes), true)
        }
        return sb
    }

    private fun append(sb: SpannableStringBuilder, s: String, color: Int, bold: Boolean) {
        val start = sb.length
        sb.append(s)
        sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
}
