# -*- coding: utf-8 -*-
"""جسر بين تطبيق اندرويد وبوت Telethon Zahid.

يستدعيه BotService:   android_runner.run(config_json, files_dir)   <- يبقى شغالاً حتى stop()
                      android_runner.stop()
"""
import asyncio
import importlib
import json
import os
import shutil
import signal
import sys
import threading
import time
import traceback
from pathlib import Path

import zloop

_state = {"loop": None, "stop": None}


# ───────────── السجل: stdout/stderr الى ملف تقرأه الواجهة ─────────────
class _LogFile:
    """يكتب الى ملف السجل: وقت (HH:MM:SS) في بداية كل سطر + حجب الاسرار قبل الكتابة."""

    def __init__(self, path):
        self.path = path
        self.lock = threading.Lock()
        self._bol = True          # هل نحن في بداية سطر جديد؟
        self._secrets = []
        if os.path.exists(path) and os.path.getsize(path) > 512 * 1024:
            os.remove(path)  # لا يكبر السجل بلا حدود
        self.f = open(path, "a", encoding="utf-8", buffering=1)

    def set_secrets(self, values):
        """قيم حساسة تُستبدل بـ *** في اي نص يُكتب (api_hash / session / token)."""
        self._secrets = [v for v in values if isinstance(v, str) and len(v) >= 8]

    def write(self, s):
        if not s:
            return 0
        n = len(s)
        for sec in self._secrets:
            s = s.replace(sec, "***")
        with self.lock:
            out = []
            for part in s.splitlines(keepends=True):
                if self._bol:
                    out.append(time.strftime("%H:%M:%S "))
                out.append(part)
                self._bol = part.endswith("\n")
            self.f.write("".join(out))
        return n

    def flush(self):
        with self.lock:
            self.f.flush()

    def isatty(self):
        return False


# ───────────── تجهيز المجلد والملفات ─────────────
def _config_text(c):
    return f'''from pyrogram import Client,filters,enums
import fakeredis
r = fakeredis.FakeRedis(decode_responses=True)

sudo_id = {int(c["sudo_id"])}
bot_user = {c["bot_user"]!r}
api_id = {int(c["api_id"])}
api_hash = {c["api_hash"]!r}
session = {c["session"]!r}
token = {c["token"]!r}
sudo_command = [{int(c["sudo_id"])}]
pm = {str(c["sudo_id"])!r}
mention = {str(c["sudo_id"])!r}
plugins = dict(root="plugins")
app = Client("user:" + bot_user, api_id, api_hash, in_memory=True, session_string=session, plugins=plugins)
bot = Client(bot_user, api_id=api_id, api_hash=api_hash, bot_token=token, plugins=dict(root="plug_bot"))
'''


# ملفات بايثون داخل zahid_source مخزّنة بامتداد .pysrc (وليس .py).
# السبب: Chaquopy يحمّل ملفات .py من داخل APK ولا يستخرجها الى القرص، فلا يراها os.walk،
# اما الملفات الاخرى (خطوط وغيرها) فيستخرجها. فنسخّها هنا ونعيد اسمها الى .py لتجدها pyrogram.
_SRC_EXT = ".pysrc"


def _copy_tree(src, dst):
    """ينسخ الشجرة بدون نسخ الصلاحيات. يرجع (عدد الملفات، عدد ملفات بايثون)."""
    total = py = 0
    for root, _dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        target = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(target, exist_ok=True)
        os.chmod(target, 0o755)
        for name in files:
            out = name[: -len(_SRC_EXT)] + ".py" if name.endswith(_SRC_EXT) else name
            d = os.path.join(target, out)
            if os.path.lexists(d):
                os.chmod(d, 0o644)
                os.remove(d)
            shutil.copyfile(os.path.join(root, name), d)
            os.chmod(d, 0o644)
            total += 1
            py += out.endswith(".py")
    return total, py


def _prepare(cfg, base):
    here = os.path.dirname(os.path.abspath(__file__))
    src = os.path.join(here, "zahid_source")
    run = os.path.join(base, "zahid_run")
    os.makedirs(run, exist_ok=True)
    # ننسخ الاكواد في كل تشغيل (تحديث التطبيق = تحديث الاكواد) ونبقي بيانات المستخدم (temp, data.json).
    # ملفات التطبيق المضمّنة للقراءة فقط، فنكتب بدون نسخ الصلاحيات ونحذف النسخة القديمة اولاً.
    os.chmod(run, 0o755)
    total, py = _copy_tree(src, run)
    print(f"[setup] نُسخ {total} ملف (منها {py} ملف بايثون)")
    for need in ("arabcompat.py", os.path.join("plugins", "arabx_fun.py"), os.path.join("plug_bot", "menu.py")):
        if not os.path.isfile(os.path.join(run, need)):
            raise RuntimeError(f"ملف ناقص بعد النسخ: {need} — المصدر: {src}")
    with open(os.path.join(run, "config.py"), "w", encoding="utf-8") as f:
        f.write(_config_text(cfg))
    os.makedirs(os.path.join(run, "temp"), exist_ok=True)
    os.chdir(run)
    if run not in sys.path:
        sys.path.insert(0, run)
    return run


def _patch_process():
    """اشياء تقتل تطبيق اندرويد او تفشل خارج الخيط الرئيسي."""
    orig = signal.signal

    def safe_signal(sig, handler):
        try:
            return orig(sig, handler)
        except ValueError:  # ليس الخيط الرئيسي
            return None
    signal.signal = safe_signal

    def android_exit(code=0):  # اوامر (ايقاف / اعاده تشغيل) تستدعي os._exit
        try:
            from java import jclass
            jclass("com.zahid.bot.BotService").requestExit(int(code))
        except Exception:
            traceback.print_exc()
    os._exit = android_exit


def _count_handlers(mod, handler_cls):
    """نفس طريقة pyrogram: اي عنصر في الوحدة له .handlers = [(Handler, group)]."""
    n = 0
    for name in list(vars(mod)):
        try:
            for h, g in getattr(mod, name).handlers:
                if (handler_cls is None or isinstance(h, handler_cls)) and isinstance(g, int):
                    n += 1
        except Exception:
            pass
    return n


def _preflight_plugins(run):
    """يستورد كل اضافة على حدة قبل تشغيل pyrogram.

    - اضافة معطوبة (خطأ استيراد/صياغة) تُسجَّل في السجل وتُحذف من نسخة التشغيل فقط، فلا تُسقط البوت كله.
    - اذا لم يُسجَّل اي امر في plugins (مثلاً الملفات ناقصة) نرفع خطأً صريحاً بدل بوت شغّال لا يستجيب.
    يرجع (عدد الاوامر، عدد الاضافات السليمة، عدد المعطوبة).
    """
    try:
        from pyrogram.handlers.handler import Handler
    except Exception:
        Handler = None
    cmds = ok = bad = 0
    for folder in ("plugins", "plug_bot"):
        base = Path(run) / folder
        for path in sorted(base.rglob("*.py")):
            mod_name = ".".join((folder,) + path.relative_to(base).with_suffix("").parts)
            try:
                mod = importlib.import_module(mod_name)
            except (Exception, SystemExit) as e:
                bad += 1
                sys.modules.pop(mod_name, None)
                tb = traceback.extract_tb(e.__traceback__)[-1:] if e.__traceback__ else []
                where = f" ({tb[0].filename.rsplit('/', 1)[-1]}:{tb[0].lineno})" if tb else ""
                print(f"[setup] ⚠ فشل تحميل الاضافة {mod_name}: {type(e).__name__}: {str(e)[:150]}{where} — تم تخطيها")
                try:
                    os.remove(path)
                except OSError:
                    pass
                continue
            ok += 1
            if folder == "plugins":
                cmds += _count_handlers(mod, Handler)
    print(f"[setup] الاضافات: {ok} سليمة، {bad} معطوبة، الاوامر المسجلة: {cmds}")
    if cmds == 0:
        raise RuntimeError("لم يُسجَّل اي امر من مجلد plugins — الاضافات ناقصة او معطوبة (راجع اسطر [setup] أعلاه)")
    return cmds, ok, bad


async def _warm_peers(client):
    """الجلسة in_memory تبدأ بلا اي قناة/مجموعة معروفة، فتفشل الاوامر بـ "Peer id invalid".
    نقرأ المحادثات مرة بعد الاتصال ليتعرّف pyrogram عليها."""
    try:
        n = 0
        async for _d in client.get_dialogs():
            n += 1
        print(f"[setup] تم تحميل {n} محادثة في الذاكرة")
    except Exception as e:
        print("[setup] تحذير: تعذّر تحميل المحادثات:", type(e).__name__, e)


async def _main():
    _preflight_plugins(os.getcwd())
    from config import app, bot
    await app.start()
    await bot.start()
    print("✅ البوت شغّال")
    try:  # تأكيد الاتصال الفعلي للواجهة (حالة "متصل" لا تظهر قبل هذه اللحظة)
        from java import jclass
        jclass("com.zahid.bot.BotService").markConnected()
    except Exception as e:
        print("markConnected:", type(e).__name__)
    warm = asyncio.ensure_future(_warm_peers(app))
    try:  # ننتظر قليلاً ليكون الكاش جاهزاً قبل اول امر، ويكمل في الخلفية اذا طال
        await asyncio.wait_for(asyncio.shield(warm), 15)
    except asyncio.TimeoutError:
        print("[setup] تحذير: تحميل المحادثات ما زال جارياً في الخلفية")
    try:
        from arabcompat import start_background
        start_background()
    except Exception as e:
        print("background:", e)
    await _state["stop"].wait()
    for c in (bot, app):
        try:
            await c.stop()
        except Exception:
            pass
    print("تم ايقاف البوت")


async def _make_event():
    return asyncio.Event()


def run(config_json, files_dir):
    """يُستدعى من خيط في الخدمة؛ يبقى شغالاً حتى stop(). كل العمل على الحلقة المشتركة (zloop)."""
    sys.stdout = sys.stderr = _LogFile(os.path.join(files_dir, "zahid.log"))
    print("=" * 30, time.strftime("%Y-%m-%d %H:%M:%S"))
    try:
        cfg = json.loads(config_json)
        sys.stdout.set_secrets([cfg.get("api_hash"), cfg.get("session"), cfg.get("token")])
        _prepare(cfg, files_dir)
        _patch_process()
        _state["loop"] = zloop.get_loop()
        _state["stop"] = zloop.run_coro(_make_event())
        zloop.run_coro(_main())
    except BaseException:
        traceback.print_exc()
        raise
    finally:
        sys.stdout.flush()


def stop():
    loop, ev = _state.get("loop"), _state.get("stop")
    if loop and ev:
        loop.call_soon_threadsafe(ev.set)
