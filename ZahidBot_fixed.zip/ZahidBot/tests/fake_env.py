# -*- coding: utf-8 -*-
"""بيئة محاكاة: pyrogram و fakeredis و java (Chaquopy) وبقية المكتبات غير المتوفرة محلياً.

الهدف: استيراد كل الاضافات فعلياً (كما يفعل pyrogram) للتأكد من خلوها من اخطاء الاستيراد/الصياغة/الاسماء الناقصة،
دون الحاجة لانترنت او مكتبات أندرويد.
"""
import asyncio
import importlib
import importlib.abc
import importlib.machinery
import sys
import types

CALLS = []          # سجل استدعاءات المحاكي (للتحقق في الاختبارات)


class _Meta(type):
    def __getattr__(cls, n):
        if n.startswith("__"):
            raise AttributeError(n)
        return _Any

    def __or__(cls, o):
        return _Any()
    __ror__ = __and__ = __rand__ = __or__

    def __invert__(cls):
        return _Any()

    def __iter__(cls):
        return iter(())


class _Any(metaclass=_Meta):
    def __init__(self, *a, **k):
        pass

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        return _Any()

    def __call__(self, *a, **k):
        return _Any()

    def __or__(self, o):
        return self
    __ror__ = __and__ = __rand__ = __or__

    def __invert__(self):
        return self

    def __iter__(self):
        return iter(())

    def __await__(self):
        return iter(())
        yield  # pragma: no cover


class Handler:
    pass


class _HandlerMod(types.ModuleType):
    """pyrogram.handlers: اي اسم *Handler هو صنف فرعي من Handler."""
    __path__ = []

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        cls = type(n, (Handler,), {"__init__": lambda self, cb=None, flt=None, *a, **k: setattr(self, "cb", cb)})
        setattr(self, n, cls)
        return cls


class _ErrMod(types.ModuleType):
    """pyrogram.errors: اي اسم هو استثناء حقيقي (حتى يعمل except)."""
    __path__ = []

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        cls = type(n, (Exception,), {})
        setattr(self, n, cls)
        return cls


class _AnyMod(types.ModuleType):
    __path__ = []

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        return _Any


class Client:
    def __init__(self, name, api_id=None, api_hash=None, *a, **k):
        self.name, self.kw, self._added, self.started, self.me = name, k, [], False, None
        CALLS.append(("Client", name, k.get("plugins")))

    def add_handler(self, h, group=0):
        self._added.append((h, group))

    def _deco(kind):
        def on(self, flt=None, group=0):
            def deco(fn):
                H = sys.modules["pyrogram.handlers"]
                self.add_handler(getattr(H, kind)(fn, flt), group)
                return fn
            return deco
        return on
    on_message = _deco("MessageHandler")
    on_callback_query = _deco("CallbackQueryHandler")
    on_inline_query = _deco("InlineQueryHandler")
    on_chosen_inline_result = _deco("ChosenInlineResultHandler")
    on_raw_update = _deco("RawUpdateHandler")
    on_edited_message = _deco("EditedMessageHandler")
    on_deleted_messages = _deco("DeletedMessagesHandler")
    on_user_status = _deco("UserStatusHandler")
    on_chat_member_updated = _deco("ChatMemberUpdatedHandler")
    on_disconnect = _deco("DisconnectHandler")
    del _deco

    async def start(self):
        self.started = True
        CALLS.append(("start", self.name))
        return self

    async def stop(self):
        self.started = False
        CALLS.append(("stop", self.name))

    async def get_dialogs(self, limit=0):
        CALLS.append(("get_dialogs", self.name))
        for i in range(3):
            yield i

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)

        async def f(*a, **k):
            return _Any()
        return f


class _Pyrogram(types.ModuleType):
    __path__ = []
    _SUBS = ("errors", "types", "handlers", "raw", "enums", "filters", "file_id", "utils", "session", "crypto", "methods")

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        if n in self._SUBS:
            return importlib.import_module("pyrogram." + n)
        return _Any


class _FakeFinder(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """يصنع اي وحدة pyrogram.* عند الطلب."""

    def find_spec(self, name, path, target=None):
        if name == "pyrogram" or name.startswith("pyrogram."):
            return importlib.machinery.ModuleSpec(name, self, is_package=True)
        return None

    def create_module(self, spec):
        n = spec.name
        if n == "pyrogram":
            m = _Pyrogram(n)
            m.Client = Client
            return m
        if n == "pyrogram.errors":
            return _ErrMod(n)
        if n == "pyrogram.handlers":
            return _HandlerMod(n)
        if n == "pyrogram.handlers.handler":
            m = types.ModuleType(n)
            m.Handler = Handler
            return m
        return _AnyMod(n)

    def exec_module(self, module):
        pass


class _FakeRedis:
    def __init__(self, *a, **k):
        self._d = {}

    def get(self, k):
        return self._d.get(k)

    def set(self, k, v, *a, **kw):
        self._d[k] = v
        return True

    def delete(self, *ks):
        for k in ks:
            self._d.pop(k, None)

    def __getattr__(self, n):
        if n.startswith("__"):
            raise AttributeError(n)
        return lambda *a, **k: None


# المكتبات المعلنة في build.gradle.kts (+ ما تسحبه تلقائياً) — اسماء الاستيراد وليس اسماء pip
DECLARED = {
    "pyrogram", "pyaes", "socks", "redis", "fakeredis", "telegraph", "yt_dlp", "youtubesearchpython", "httpx",
    "httpcore", "h11", "anyio", "sniffio", "PIL", "requests", "urllib3", "certifi", "idna", "charset_normalizer",
    "bs4", "soupsieve", "pytz", "pyfiglet", "aiohttp", "aiosignal", "frozenlist", "multidict", "yarl", "attr",
    "attrs", "async_timeout", "urlextract", "qrcode", "emoji", "cowpy", "speedtest", "prettytable", "wcwidth",
    "geopy", "geographiclib", "gtts", "click", "barcode", "pySmartDL", "cloudscraper", "pyparsing",
    "requests_toolbelt", "psutil", "sortedcontainers", "typing_extensions",
}


class _FakeThirdParty(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """للمكتبات المعلنة التي لا تتوفر محلياً: وحدة بديلة (حتى نعرف ان الاستيراد سيصح على الجهاز)."""

    def find_spec(self, name, path, target=None):
        top = name.split(".")[0]
        if top in DECLARED and top != "pyrogram":
            return importlib.machinery.ModuleSpec(name, self, is_package=True)
        return None

    def create_module(self, spec):
        n = spec.name
        if n == "fakeredis":
            m = _AnyMod(n)
            m.FakeRedis = _FakeRedis
            m.FakeStrictRedis = _FakeRedis
            return m
        return _AnyMod(n)

    def exec_module(self, module):
        pass


def install(java=True):
    """يُسجّل المحاكيات. المكتبات المتوفرة فعلياً محلياً (requests, PIL) تبقى حقيقية."""
    sys.meta_path.insert(0, _FakeFinder())
    sys.meta_path.append(_FakeThirdParty())   # يأتي اخيراً: الحقيقي أولاً
    if java:
        j = types.ModuleType("java")

        class _JC:
            def __init__(self, n):
                self.n = n

            def __getattr__(self, m):
                return lambda *a, **k: CALLS.append(("java", self.n, m, a))
        j.jclass = lambda n: _JC(n)
        sys.modules["java"] = j
