# -*- coding: utf-8 -*-
"""اختبار الاختبارات: يُعيد ادخال أخطاء حقيقية سابقة على نسخة مؤقتة ويتأكد أن المجموعة تفشل (تلتقطها).
التشغيل:  python tests/mutation_check.py"""
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PY = "app/src/main/python"
KT = "app/src/main/java/com/zahid/bot"


def sub(path, old, new, count=1):
    def f(root):
        p = root / path
        s = p.read_text(encoding="utf-8")
        assert old in s, f"النص غير موجود في {path}: {old[:40]}"
        p.write_text(s.replace(old, new, count), encoding="utf-8")
    return f


def rename(src, dst):
    return lambda root: (root / src).rename(root / dst)


def copytree_bug(root):      # الخطأ الاصلي: Errno 13 عند التشغيل الثاني
    p = root / PY / "android_runner.py"
    s = p.read_text(encoding="utf-8")
    a, b = s.index("def _copy_tree"), s.index("def _prepare")
    p.write_text(s[:a] + "def _copy_tree(src, dst):\n    shutil.copytree(src, dst, dirs_exist_ok=True)\n    return 1, 1\n\n\n" + s[b:], encoding="utf-8")


MUTATIONS = {
    "copytree القديم (Errno 13)": (copytree_bug, "test_copy_repeat_over_locked_state"),
    "ملف .py داخل zahid_source (لا يُنسخ على الجهاز)": (rename(f"{PY}/zahid_source/arabcompat.pysrc", f"{PY}/zahid_source/arabcompat.py"), "test_layout_pysrc"),
    "اضافة معطوبة تُسقط التشغيل (بدون فحص مسبق)": (sub(f"{PY}/android_runner.py", "                continue\n            ok += 1", "                raise\n            ok += 1"), "test_preflight_skips_broken_plugins"),
    "دالة مفقودة getGrChAuto": (sub(f"{PY}/zahid_source/plugins/arabx_account.pysrc", "def getGrChAuto():", "def getGrChAuto_x():"), "test_preflight_real_plugins"),
    "اسم غير معرّف جديد في اضافة": (sub(f"{PY}/zahid_source/plugins/arabx_system.pysrc", 'await event.edit("• جاري القياس ..")', 'await event.edit(undefined_name_xyz)'), "test_preflight_real_plugins"),
    "مكتبة غير مثبتة بلا حماية": (sub(f"{PY}/zahid_source/plugins/arabx_system.pysrc", "import os\n", "import os\nimport numpy\n"), "test_third_party_imports_are_declared"),
    "صياغة 3.12 فقط (f-string)": (sub(f"{PY}/zahid_source/plugins/arabx_system.pysrc", "def _fmt(sec):", "X = {'a': 1}\nY = f\"{X[\"a\"]}\"\n\n\ndef _fmt(sec):"), "test_no_py312_only_syntax_or_api"),
    "findViewById بنوع خاطئ (ClassCastException)": (sub(f"{KT}/MainActivity.kt", "findViewById<View>(R.id.btnHomeLogClear)", "findViewById<ImageButton>(R.id.btnHomeLogClear)"), "test_findviewbyid_types_match_layout"),
    "id غير موجود في التخطيط": (sub(f"{KT}/MainActivity.kt", "R.id.cardAppInfo", "R.id.cardAppInfoXX"), "test_r_references_exist"),
    "قوس غير مغلق في Kotlin": (sub(f"{KT}/MainActivity.kt", "private fun confirmClearLog() {", "private fun confirmClearLog() {{"), "test_brackets_balanced"),
    "lateinit بلا اسناد": (sub(f"{KT}/MainActivity.kt", "tvHomeLog = findViewById(R.id.tvHomeLog)", "val _unused = 1"), "test_lateinit_properties_are_assigned"),
    "لون غير موجود في XML": (sub("app/src/main/res/layout/page_home.xml", "@color/zp_neon", "@color/zp_neon_missing"), "test_resource_references_exist"),
    "مسار vector معطوب": (sub("app/src/main/res/drawable/ic_gear.xml", "M19.14,12.94c0.04,-0.3", "M19.14c0.04,-0.3"), "test_vector_paths_valid"),
    "شريط تبويب ثانٍ يعود": (sub("app/src/main/res/layout/activity_main.xml", "    <!-- صفحات التبويبات", '    <LinearLayout android:id="@+id/topTabs" android:layout_width="match_parent" android:layout_height="1dp"/>\n    <!-- صفحات التبويبات'), "test_single_tab_bar"),
    "نوع الخدمة الامامية مفقود (انهيار أندرويد 14)": (sub("app/src/main/AndroidManifest.xml", 'android:foregroundServiceType="specialUse"', ""), "test_foreground_service_type_and_permission"),
    "تسريب الاسرار في السجل": (sub(f"{PY}/android_runner.py", "sys.stdout.set_secrets([cfg.get(\"api_hash\"), cfg.get(\"session\"), cfg.get(\"token\")])", "pass"), "test_full_start_stop_cycle"),
    "عدم تحميل المحادثات (Peer id invalid)": (sub(f"{PY}/android_runner.py", "async for _d in client.get_dialogs():", "async for _d in _noop():"), "test_full_start_stop_cycle"),
    "تكرار group بين معالجين": (sub(f"{PY}/zahid_source/arabcompat.pysrc", "g = next(_GROUP)", "g = 7"), "test_preflight_real_plugins"),
}


def main():
    ok = True
    for name, (mut, test) in MUTATIONS.items():
        tmp = Path(tempfile.mkdtemp(prefix="zbm_"))
        try:
            dst = tmp / "p"
            shutil.copytree(ROOT, dst, ignore=shutil.ignore_patterns("__pycache__", ".git", "build"))
            mut(dst)
            r = subprocess.run([sys.executable, str(dst / "tests" / "test_zahid.py"), "-k", test], capture_output=True, text=True, timeout=300)
            caught = r.returncode != 0
            print(("✔ التُقط  " if caught else "✘ لم يُلتقط"), "—", name, f"[{test}]")
            ok &= caught
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    print("\nالنتيجة:", "كل الأخطاء المُدخلة التُقطت" if ok else "بعض الاخطاء لم تلتقطها الاختبارات!")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
