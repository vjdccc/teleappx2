# -*- coding: utf-8 -*-
"""سيناريوهات تُشغَّل في عملية منفصلة (لعزل sys.modules)، وتطبع JSON في آخر سطر."""
import json
import os
import shutil
import sys
import tempfile
import threading
import time
import types

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fake_env  # noqa: E402

PYDIR = os.environ["ZB_PYDIR"]            # مجلد python الذي فيه android_runner و zahid_source
TMP = os.environ["ZB_TMP"]
CFG = dict(sudo_id=123456, bot_user="my_bot", api_id=12345, api_hash="abcdef0123456789abcdef0123456789",
           session="BQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", token="123456:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")


def load_runner():
    sys.path.insert(0, PYDIR)
    import android_runner
    return android_runner


def out(**kw):
    # android_runner.run يحوّل sys.stdout الى ملف السجل، فنكتب النتيجة على stdout الاصلي
    sys.__stdout__.write("\n@@" + json.dumps(kw, ensure_ascii=False) + "\n")
    sys.__stdout__.flush()


# كود ميّت لا يمكن الوصول اليه (لا مستدعي له / داخل شرط Config فارغ / ميزة SQL محذوفة). كل اسم جديد خارج القائمة = فشل.
KNOWN_DEAD = {
    "plugins.arabx_account": {"a@potocmd"},                                 # أمر zz_unused_cmd لا يُكتب
    "plugins.arabx_group": {"MessageActionChannelMigrateFrom@fetch_info", "getchat@get_call", "getvc@get_call"},  # بلا مستدعٍ
    "plugins.arabx_pm": {f"{n}@do_pm_{a}_action" for n in ("sql", "sqllist") for a in ("permit", "options", "enquire", "request", "chat", "spam")},
    "plugins.arabx_source": {"getsubitems@prettyjson", "indentitems@prettyjson", "load_module@install"} | {f"help{i}@inlinezahid" for i in (1, 2)},
}


def _fn_loads(tree):
    """لكل دالة: الاسماء التي تُقرأ فعلاً (تحليل AST يتجاهل تعليقات الانواع المحلية x: T التي لا تُنفَّذ)."""
    import ast
    res = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            skip = set()
            for sub in ast.walk(node):
                if isinstance(sub, ast.AnnAssign) and isinstance(sub.target, ast.Name):
                    skip |= {id(x) for x in ast.walk(sub.annotation)}
            res[(node.name, node.lineno)] = {x.id for x in ast.walk(node) if isinstance(x, ast.Name) and isinstance(x.ctx, ast.Load) and id(x) not in skip}
    return res


def undefined_globals(run, modnames):
    """اسماء عامة تُقرأ داخل دوال/اصناف الاضافات ولا وجود لها في الوحدة ولا في builtins (= NameError عند التنفيذ)."""
    import ast
    import builtins
    import symtable
    bad, dead = {}, {}
    for mn in modnames:
        mod = sys.modules.get(mn)
        if mod is None or not getattr(mod, "__file__", None):
            continue
        src = open(mod.__file__, encoding="utf-8").read()
        top = symtable.symtable(src, mod.__file__, "exec")
        loads = _fn_loads(ast.parse(src))
        ns = vars(mod)

        def walk(t):
            for ch in t.get_children():
                for sym in ch.get_symbols():
                    n = sym.get_name()
                    if sym.is_global() and sym.is_referenced() and not sym.is_assigned():
                        if n in ns or hasattr(builtins, n):
                            continue
                        key = (ch.get_name(), ch.get_lineno())
                        if ch.get_type() == "function" and key in loads and n not in loads[key]:
                            continue                      # ظهر فقط في تعليق نوع محلي
                        tag = f"{n}@{ch.get_name()}"
                        (dead if tag in KNOWN_DEAD.get(mn, ()) else bad).setdefault(mn, set()).add(f"{tag}:{ch.get_lineno()}")
                walk(ch)
        walk(top)
    return {k: sorted(v) for k, v in bad.items()}, sum(len(v) for v in dead.values())


def scenario_preflight_real():
    ar = load_runner()
    fake_env.install()
    base = os.path.join(TMP, "files"); os.makedirs(base)
    run = ar._prepare(CFG, base)
    cmds, ok, bad = ar._preflight_plugins(run)
    mods = [m for m in sys.modules if m.split(".")[0] in ("plugins", "plug_bot") or m in ("arabcompat", "arabhelpers", "arabstyle", "config")]
    und, dead = undefined_globals(run, mods)
    # pyrogram ينفّذ اول معالج مطابق فقط داخل كل group → تكرار group بين اضافتين يُخفي أوامر
    groups = []
    for mn in mods:
        if not mn.startswith("plugins"):
            continue
        for name in list(vars(sys.modules[mn])):
            try:
                groups += [g for h, g in getattr(sys.modules[mn], name).handlers]
            except Exception:
                pass
    out(cmds=cmds, ok=ok, bad=bad, mods=len(mods), undefined=und, dead=dead, groups=len(groups), unique_groups=len(set(groups)),
        all_int=all(isinstance(g, int) for g in groups))


def scenario_preflight_broken():
    ar = load_runner()
    fake_env.install()
    base = os.path.join(TMP, "files"); os.makedirs(base)
    # ملفان معطوبان: خطأ صياغة + خطأ استيراد
    pl = os.path.join(PYDIR, "zahid_source", "plugins")
    open(os.path.join(pl, "zz_broken_syntax.pysrc"), "w", encoding="utf-8").write("def x(:\n  pass\n")
    open(os.path.join(pl, "zz_broken_import.pysrc"), "w", encoding="utf-8").write("import module_that_does_not_exist_xyz\n")
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        run = ar._prepare(CFG, base)
        cmds, ok, bad = ar._preflight_plugins(run)
    left = sorted(os.listdir(os.path.join(run, "plugins")))
    out(cmds=cmds, ok=ok, bad=bad, broken_removed=not any(f.startswith("zz_broken") for f in left), lines=buf.getvalue().splitlines())


def scenario_preflight_empty():
    ar = load_runner()
    fake_env.install()
    base = os.path.join(TMP, "files"); os.makedirs(base)
    shutil.rmtree(os.path.join(PYDIR, "zahid_source", "plugins"))
    os.makedirs(os.path.join(PYDIR, "zahid_source", "plugins"))
    try:
        run = ar._prepare(CFG, base)
        ar._preflight_plugins(run)
        out(raised=False)
    except RuntimeError as e:
        out(raised=True, msg=str(e))


def scenario_missing_core():
    ar = load_runner()
    os.remove(os.path.join(PYDIR, "zahid_source", "arabcompat.pysrc"))
    base = os.path.join(TMP, "files"); os.makedirs(base)
    try:
        ar._prepare(CFG, base)
        out(raised=False)
    except RuntimeError as e:
        out(raised=True, msg=str(e))


def scenario_copy_repeat():
    """اعادة نسخ 3 مرات فوق مجلد مقفل قديم + مصدر للقراءة فقط (يُشغَّل بمستخدم غير root)."""
    ar = load_runner()
    base = os.path.join(TMP, "files"); os.makedirs(base)
    run = os.path.join(base, "zahid_run")
    os.makedirs(os.path.join(run, "styles"))
    f = os.path.join(run, "styles", "digital.ttf"); open(f, "w").write("OLD"); os.chmod(f, 0o444)
    os.makedirs(os.path.join(run, "temp")); open(os.path.join(run, "temp", "keep.txt"), "w").write("user data")
    os.chmod(os.path.join(run, "styles"), 0o555); os.chmod(run, 0o555)
    res = []
    for _ in range(3):
        ar._prepare(CFG, base); os.chdir("/")
        res.append((os.path.getsize(f) > 1000, os.path.isfile(os.path.join(run, "arabcompat.py")),
                    open(os.path.join(run, "temp", "keep.txt")).read() == "user data"))
    leftover = [x for _, _, fs in os.walk(run) for x in fs if x.endswith(".pysrc")]
    cfgtxt = open(os.path.join(run, "config.py"), encoding="utf-8").read()
    out(res=res, leftover=leftover, cfg_ok="sudo_id = 123456" in cfgtxt)


def scenario_integration():
    """تشغيل كامل: run() ثم stop() بمحاكي pyrogram — نفس مسار التطبيق."""
    ar = load_runner()
    fake_env.install()
    files = os.path.join(TMP, "files"); os.makedirs(files)
    # اضافة تطبع الاسرار عمداً (print + استثناء) للتأكد انها تُحجب من السجل
    leak = ("print('LEAK api_hash=%s')\nprint('LEAK session=%s')\nprint('LEAK token=%s')\n"
            % (CFG["api_hash"], CFG["session"], CFG["token"]))
    open(os.path.join(PYDIR, "zahid_source", "plugins", "zz_leak.pysrc"), "w", encoding="utf-8").write(leak)
    err = []
    t = threading.Thread(target=lambda: (ar.run(json.dumps(CFG), files)), daemon=True)
    t.start()
    log = os.path.join(files, "zahid.log")

    def text():
        try:
            return open(log, encoding="utf-8").read()
        except FileNotFoundError:
            return ""
    for _ in range(300):
        if "✅ البوت شغّال" in text() and "تحميل 3 محادثة" in text():
            break
        time.sleep(0.1)
    started = "✅ البوت شغّال" in text()
    time.sleep(0.5)
    mid = text()
    ar.stop()
    t.join(15)
    final = text()
    calls = fake_env.CALLS
    out(started=started, finished=not t.is_alive(), stopped_msg="تم ايقاف البوت" in final,
        marked=any(c[0] == "java" and c[2] == "markConnected" for c in calls),
        started_clients=sorted(c[1] for c in calls if c[0] == "start"),
        stopped_clients=sorted(c[1] for c in calls if c[0] == "stop"),
        warmed=any(c[0] == "get_dialogs" for c in calls),
        setup_lines=[l for l in final.splitlines() if "[setup]" in l],
        no_traceback="Traceback" not in final,
        no_task_errors=not any(w in final for w in ("Task exception", "NameError", "was never retrieved", "Error:")),
        log_lines=final.splitlines(),
        secrets_leaked=any(s in final for s in (CFG["api_hash"], CFG["session"], CFG["token"])),
        masked=final.count("LEAK api_hash=***") + final.count("LEAK session=***") + final.count("LEAK token=***"),
        tail=final[-600:])


def scenario_stop_idle():
    ar = load_runner()
    ar.stop(); ar.stop()          # قبل التشغيل وبعده مرتين: لا استثناء ولا تعليق
    out(ok=True)


def scenario_dispatch():
    """تشغيل اوامر حقيقية عبر طبقة arabcompat برسالة وهمية: بنك / مدة التشغيل / ايقاف / اعاده تشغيل."""
    import asyncio
    ar = load_runner()
    fake_env.install()
    base = os.path.join(TMP, "files"); os.makedirs(base)
    run = ar._prepare(CFG, base)
    ar._patch_process()
    ar._preflight_plugins(run)
    S = sys.modules["plugins.arabx_system"]

    class Chat:
        id = 777

    class Msg:
        def __init__(self, text):
            self.id, self.chat, self.text, self.outgoing, self.media, self.web_page, self.matches = 5, Chat(), text, True, None, None, None
            self.edits = []

        async def edit_text(self, text, **k):
            self.edits.append(text)

        async def edit_caption(self, text, **k):
            self.edits.append(text)

        async def delete(self, *a, **k):
            pass

    class Cli:
        def __getattr__(self, n):
            async def f(*a, **k):
                return None
            return f

    def handler(name):
        for n in list(vars(S)):
            h = getattr(S, n)
            if getattr(h, "__name__", None) == name and hasattr(h, "handlers"):
                return h
        raise KeyError(name)

    async def run_cmd(name, text):
        m = Msg(text)
        await handler(name)(Cli(), m)
        return m.edits

    loop = asyncio.new_event_loop()
    res = {}
    for name, text in (("_ping", "بنك"), ("_uptime", "مدة التشغيل"), ("_stop", "ايقاف"), ("_restart", "اعاده تشغيل")):
        try:
            res[name] = loop.run_until_complete(run_cmd(name, text))
        except Exception as e:
            res[name] = f"EXC {type(e).__name__}: {e}"
    exits = [c[3] for c in fake_env.CALLS if c[0] == "java" and c[2] == "requestExit"]
    out(res=res, exits=exits)


if __name__ == "__main__":
    globals()["scenario_" + sys.argv[1]]()
