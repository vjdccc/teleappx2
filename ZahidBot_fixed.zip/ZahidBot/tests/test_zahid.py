# -*- coding: utf-8 -*-
"""اختبارات مشروع ZahidBot — تعمل بدون اندرويد ولا انترنت:  python tests/test_zahid.py

القسم 1: كود بايثون (النسخ، الاعدادات، السجل، تحميل كل الاضافات، الاسماء غير المعرّفة، توافق 3.11).
القسم 2: موارد اندرويد (XML، المراجع، الانواع بين Kotlin والتخطيط، Manifest، الأيقونات).
"""
import ast
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
import xml.dom.minidom as minidom
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAIN = ROOT / "app" / "src" / "main"
PYDIR = MAIN / "python"
RES = MAIN / "res"
KT = sorted((MAIN / "java").rglob("*.kt"))
TESTS = Path(__file__).resolve().parent


# ───────────────────────── مساعدات ─────────────────────────
def _drop_priv():
    if os.getuid() == 0:
        os.setgid(65534)
        os.setuid(65534)


def run_driver(scenario, unpriv=False, readonly_src=False, timeout=120):
    """ينسخ المشروع الى مجلد مؤقت ويشغّل السيناريو في عملية منفصلة. يرجع (dict, stdout كامل)."""
    tmp = Path(tempfile.mkdtemp(prefix="zb_"))
    try:
        py = tmp / "py"
        shutil.copytree(PYDIR, py, ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copytree(TESTS, tmp / "tests", ignore=shutil.ignore_patterns("__pycache__"))
        work = tmp / "work"
        work.mkdir()
        if readonly_src:   # مثل assets داخل التطبيق: ملفات 0444 ومجلدات 0555
            for d, _, fs in os.walk(py / "zahid_source"):
                for f in fs:
                    os.chmod(os.path.join(d, f), 0o444)
            for d, _, _ in os.walk(py / "zahid_source"):
                os.chmod(d, 0o555)
        for p in (tmp, py, tmp / "tests", work):
            os.chmod(p, 0o777 if p == work else 0o755)
        for d, ds, fs in os.walk(tmp):
            for x in ds + fs:
                full = os.path.join(d, x)
                if not os.path.islink(full) and not (readonly_src and "zahid_source" in full):
                    os.chmod(full, os.stat(full).st_mode | 0o444 | (0o111 if os.path.isdir(full) else 0))
        if unpriv and os.getuid() == 0:
            os.chown(work, 65534, 65534)
        env = dict(os.environ, ZB_PYDIR=str(py), ZB_TMP=str(work), PYTHONDONTWRITEBYTECODE="1")
        pre = _drop_priv if (unpriv and os.getuid() == 0) else None
        r = subprocess.run([sys.executable, str(tmp / "tests" / "_driver.py"), scenario], env=env, capture_output=True,
                           text=True, timeout=timeout, preexec_fn=pre, cwd="/")
        last = [l for l in r.stdout.splitlines() if l.startswith("@@")]
        if not last:
            raise AssertionError(f"السيناريو {scenario} لم يُرجع نتيجة.\nSTDOUT:\n{r.stdout[-1500:]}\nSTDERR:\n{r.stderr[-2500:]}")
        return json.loads(last[-1][2:]), r.stdout
    finally:
        for d, _, _ in os.walk(tmp):
            try:
                os.chmod(d, 0o777)
            except OSError:
                pass
        shutil.rmtree(tmp, ignore_errors=True)


def _kotlin_classify(body):
    """نفس منطق LogFormat.classify في Kotlin (التعابير تُقرأ من الملف نفسه حتى لا ينحرف الاختبار عنه)."""
    src = (MAIN / "java" / "com" / "zahid" / "bot" / "LogFormat.kt").read_text(encoding="utf-8")

    def rx(name):
        m = re.search(rf'val {name}\s*=\s*Regex\("((?:\\\\.|[^"\\])*)"', src)
        return re.compile(m.group(1).replace("\\\\", "\\"), re.I)
    if rx("ERROR_RE").search(body):
        return "ERROR"
    if rx("WARN_RE").search(body):
        return "WARNING"
    if rx("OK_RE").search(body):
        return "SUCCESS"
    if rx("DEBUG_RE").search(body):
        return "DEBUG"
    return "INFO"


def py_sources():
    return sorted(PYDIR.rglob("*.py")) + sorted(PYDIR.rglob("*.pysrc"))


# ═════════════════════════ 1) بايثون ═════════════════════════
class T01_PythonSources(unittest.TestCase):
    def test_layout_pysrc(self):
        """كل مصادر zahid_source بامتداد .pysrc (لأن Chaquopy لا يستخرج .py الى القرص)."""
        stray = [str(p.relative_to(PYDIR)) for p in (PYDIR / "zahid_source").rglob("*.py")]
        self.assertEqual(stray, [], "ملفات .py داخل zahid_source لن تُنسخ على الجهاز")
        self.assertGreaterEqual(len(list((PYDIR / "zahid_source").rglob("*.pysrc"))), 20)

    def test_required_files_exist(self):
        for rel in ("arabcompat", "arabhelpers", "arabstyle", "plug_bot/menu", "plugins/arabx_system", "plugins/arabx_fun"):
            self.assertTrue((PYDIR / "zahid_source" / f"{rel}.pysrc").is_file(), rel)
        for f in ("android_runner.py", "zloop.py", "setup_helper.py"):
            self.assertTrue((PYDIR / f).is_file(), f)
        for f in ("digital.ttf", "impact.ttf"):
            self.assertGreater((PYDIR / "zahid_source" / "styles" / f).stat().st_size, 1000, f)

    def test_all_sources_compile_py311(self):
        """ترجمة كل المصادر بقواعد 3.11 (نسخة Chaquopy) بدل 3.12 المحلية."""
        for p in py_sources():
            src = p.read_text(encoding="utf-8")
            try:
                ast.parse(src, filename=str(p), feature_version=(3, 11))
            except SyntaxError as e:
                self.fail(f"{p.name}:{e.lineno} {e.msg}")

    def test_no_py312_only_syntax_or_api(self):
        """f-string من نوع PEP 701 (يصح في 3.12 فقط) وواجهات 3.12+ — تكسر على بايثون 3.11."""
        bad = []
        api = re.compile(r"itertools\.batched|\.walk\(\s*\)|typing\.override|from typing import[^\n]*\boverride\b|"
                         r"onexc\s*=|process_cpu_count|\bsys\.monitoring\b|^\s*type\s+\w+\s*=", re.M)
        for p in py_sources():
            src = p.read_text(encoding="utf-8")
            tree = ast.parse(src)
            for node in ast.walk(tree):
                if isinstance(node, ast.JoinedStr):
                    seg = ast.get_source_segment(src, node) or ""
                    m = re.match(r"^[rRbBuUfF]*('''|\"\"\"|'|\")", seg)
                    q = m.group(1) if m else '"'
                    for v in node.values:
                        if isinstance(v, ast.FormattedValue):
                            e = ast.get_source_segment(src, v.value) or ""
                            if "\\" in e or q[0] in e or ("\n" in e and len(q) == 1) or "#" in e:
                                bad.append(f"{p.name}:{node.lineno} f-string يحتوي {e[:40]!r}")
            for m in api.finditer(src):
                bad.append(f"{p.name}: {m.group(0).strip()}")
        self.assertEqual(bad, [], "\n".join(bad[:15]))

    def test_third_party_imports_are_declared(self):
        """كل مكتبة غير قياسية تُستورد بدون try يجب ان تكون مثبتة في build.gradle.kts."""
        sys.path.insert(0, str(TESTS))
        import fake_env
        declared, local = fake_env.DECLARED, {"arabcompat", "arabhelpers", "arabstyle", "autoname_ctl", "config", "plugins", "plug_bot", "zloop", "java", "android_runner"}
        problems, optional = [], {}
        for p in py_sources():
            tree = ast.parse(p.read_text(encoding="utf-8"))
            guarded = set()
            for n in ast.walk(tree):
                if isinstance(n, ast.Try):
                    for sub in ast.walk(n):
                        guarded.add(id(sub))
            for n in ast.walk(tree):
                names = []
                if isinstance(n, ast.Import):
                    names = [a.name for a in n.names]
                elif isinstance(n, ast.ImportFrom) and n.level == 0 and n.module:
                    names = [n.module]
                for full in names:
                    top = full.split(".")[0]
                    if top in sys.stdlib_module_names or top in local or top in declared or top == "__future__":
                        continue
                    if id(n) in guarded:
                        optional.setdefault(top, set()).add(p.name)
                    else:
                        problems.append(f"{p.name}:{n.lineno} import {full}")
        self.assertEqual(problems, [], "مكتبات غير مثبتة وتُستورد بلا حماية:\n" + "\n".join(problems[:15]))
        if optional:
            print("\n   ℹ مكتبات اختيارية غير مثبتة (الاوامر المعتمدة عليها تختفي فقط):", ", ".join(sorted(optional)))

    def test_no_invalid_escape_warnings(self):
        """\\s داخل نص عادي: تحذير اليوم وخطأ صياغة في بايثون القادمة."""
        import warnings
        bad = []
        for p in py_sources():
            src = p.read_text(encoding="utf-8")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                compile(src, str(p), "exec")
            bad += [f"{p.name}:{x.lineno}" for x in w if "invalid escape" in str(x.message)]
        self.assertEqual(bad, [], ", ".join(bad[:10]))

    def test_kotlin_log_classifier_matches_runner_messages(self):
        samples = {
            "[setup] ⚠ فشل تحميل الاضافة plugins.x: ImportError: no": "ERROR",
            "[setup] تحذير: تعذّر تحميل المحادثات: FloodWait": "WARNING",
            "✅ البوت شغّال": "SUCCESS",
            "[setup] نُسخ 22 ملف (منها 20 ملف بايثون)": "INFO",
            "[setup] الاضافات: 17 سليمة، 0 معطوبة، الاوامر المسجلة: 379": "INFO",
            "تم ايقاف البوت": "SUCCESS",
        }
        for line, want in samples.items():
            self.assertEqual(_kotlin_classify(line), want, line)

    def test_declared_libs_in_gradle(self):
        gradle = (ROOT / "app" / "build.gradle.kts").read_text(encoding="utf-8")
        for lib in ("pyrogram", "fakeredis", "Pillow", "requests", "aiohttp", "yt-dlp"):
            self.assertIn(f'install("{lib}', gradle, lib)
        self.assertIn('version = "3.11"', gradle)


class T02_Runner(unittest.TestCase):
    def test_copy_repeat_over_locked_state(self):
        """ينسخ 3 مرات فوق مجلد قديم مقفل ومصدر للقراءة فقط بمستخدم عادي (يعيد انتاج خطأ Errno 13 القديم)."""
        r, _ = run_driver("copy_repeat", unpriv=True, readonly_src=True)
        self.assertEqual(len(r["res"]), 3)
        for i, (font, core, userdata) in enumerate(r["res"], 1):
            self.assertTrue(font, f"تشغيل {i}: الخط لم يُحدَّث")
            self.assertTrue(core, f"تشغيل {i}: arabcompat.py مفقود")
            self.assertTrue(userdata, f"تشغيل {i}: بيانات المستخدم (temp) ضاعت")
        self.assertEqual(r["leftover"], [])
        self.assertTrue(r["cfg_ok"])

    def test_missing_core_file_fails_loudly(self):
        r, _ = run_driver("missing_core")
        self.assertTrue(r["raised"])
        self.assertIn("arabcompat.py", r["msg"])

    def test_preflight_real_plugins(self):
        """يستورد كل الاضافات الحقيقية كما يفعل pyrogram ويعدّ الاوامر ويبحث عن اسماء غير معرّفة."""
        r, _ = run_driver("preflight_real")
        self.assertEqual(r["bad"], 0, "اضافات معطوبة")
        self.assertGreaterEqual(r["ok"], 17)
        self.assertGreaterEqual(r["cmds"], 200, f"عدد الاوامر المسجلة قليل: {r['cmds']}")
        self.assertEqual(r["undefined"], {}, "اسماء غير معرّفة (NameError عند تنفيذ الامر):\n" + json.dumps(r["undefined"], ensure_ascii=False, indent=1)[:3000])
        self.assertEqual(r["groups"], r["unique_groups"], "تكرار group بين معالجات: pyrogram سينفّذ اول واحد فقط")
        self.assertTrue(r["all_int"])
        print(f"\n   ✔ {r['ok']} اضافة سليمة، {r['cmds']} معالج مسجّل، {r['mods']} وحدة فُحصت للاسماء غير المعرّفة ({r['dead']} اسماً في كود ميّت معروف)")

    def test_preflight_skips_broken_plugins(self):
        r, _ = run_driver("preflight_broken")
        self.assertEqual(r["bad"], 2)
        self.assertTrue(r["broken_removed"])
        self.assertGreaterEqual(r["cmds"], 200, "اضافة معطوبة أسقطت بقية الاوامر")
        bad_lines = [l for l in r["lines"] if "فشل تحميل الاضافة" in l]
        self.assertEqual(len(bad_lines), 2, r["lines"])
        for l in bad_lines:      # محلل السجل في Kotlin يصنّفها خطأً (أحمر)
            self.assertEqual(_kotlin_classify(l), "ERROR", l)

    def test_preflight_zero_commands_raises(self):
        r, _ = run_driver("preflight_empty")
        self.assertTrue(r["raised"])
        self.assertIn("plugins", r["msg"])

    def test_full_start_stop_cycle(self):
        r, out = run_driver("integration")
        self.assertTrue(r["started"], r["tail"])
        self.assertTrue(r["marked"], "markConnected لم يُستدعَ")
        self.assertEqual(r["started_clients"], ["my_bot", "user:my_bot"])
        self.assertTrue(r["warmed"], "لم تُحمَّل المحادثات (Peer id invalid)")
        self.assertTrue(r["no_traceback"], r["tail"])
        self.assertFalse(r["secrets_leaked"], "الاسرار ظهرت في السجل!")
        self.assertEqual(r["masked"], 3, "الاضافة التجريبية طبعت الاسرار ولم تُحجب كلها بـ ***")
        self.assertTrue(r["finished"], "لم ينتهِ الخيط بعد stop()")
        self.assertTrue(r["stopped_msg"])
        self.assertEqual(r["stopped_clients"], ["my_bot", "user:my_bot"])
        self.assertTrue(any("الاوامر المسجلة" in l for l in r["setup_lines"]))
        self.assertTrue(r["no_task_errors"], "اخطاء في مهام الخلفية:\n" + r["tail"])
        # كل سطر في السجل يجب ان يفهمه محلل Kotlin، والسجل النظيف لا يحتوي مستوى ERROR
        entries = [(l, _kotlin_classify(l.split(" ", 1)[1] if re.match(r"^\d\d:\d\d:\d\d ", l) else l)) for l in r["log_lines"] if l.strip()]
        errs = [l for l, lv in entries if lv == "ERROR"]
        self.assertEqual(errs, [], "تشغيل نظيف ظهر فيه مستوى خطأ:\n" + "\n".join(errs))
        ready = [lv for l, lv in entries if "البوت شغّال" in l]
        self.assertEqual(ready, ["SUCCESS"])

    def test_stop_without_start_is_safe(self):
        r, _ = run_driver("stop_idle")
        self.assertTrue(r["ok"])

    def test_real_commands_through_compat_layer(self):
        """يشغّل اوامر حقيقية (بنك، مدة التشغيل، ايقاف، اعاده تشغيل) عبر arabcompat برسالة وهمية."""
        r, _ = run_driver("dispatch")
        res = r["res"]
        for k, v in res.items():
            self.assertIsInstance(v, list, f"{k}: {v}")
        self.assertTrue(any("سرعة الاستجابه" in e for e in res["_ping"]), res["_ping"])
        self.assertTrue(any("ثانيه" in e for e in res["_uptime"]), res["_uptime"])
        self.assertTrue(any("ايقاف" in e for e in res["_stop"]))
        # ايقاف → requestExit(42) (نهائي)، اعاده تشغيل → requestExit(0) ولا يقتل الاختبار نفسه
        self.assertEqual(sorted(x[0] for x in r["exits"]), [0, 42], r["exits"])


class T03_Config(unittest.TestCase):
    def _import_runner(self):
        sys.path.insert(0, str(PYDIR))
        sys.path.insert(0, str(TESTS))
        import fake_env
        fake_env.install()
        import android_runner
        return android_runner

    def test_config_text_is_valid_python_for_nasty_inputs(self):
        ar = self._import_runner()
        nasty = dict(sudo_id="777", bot_user="b'o\"t\\", api_id="12", api_hash="h'\"\\\n#", session="س'ــ\"\\", token="1:'\"")
        txt = ar._config_text(nasty)
        ns = {}
        exec(compile(txt, "config.py", "exec"), ns)
        self.assertEqual(ns["sudo_id"], 777)
        self.assertEqual(ns["bot_user"], nasty["bot_user"])
        self.assertEqual(ns["api_hash"], nasty["api_hash"])
        self.assertEqual(ns["session"], nasty["session"])
        self.assertEqual(ns["sudo_command"], [777])

    def test_config_keys_match_kotlin_prefs(self):
        prefs = (MAIN / "java" / "com" / "zahid" / "bot" / "Prefs.kt").read_text(encoding="utf-8")
        m = re.search(r"FIELDS\s*=\s*listOf\(([^)]*)\)", prefs)
        self.assertTrue(m, "FIELDS غير موجود في Prefs.kt")
        fields = set(re.findall(r'"(\w+)"', m.group(1)))
        ar = self._import_runner()
        txt = (PYDIR / "android_runner.py").read_text(encoding="utf-8")
        used = set(re.findall(r'c\["(\w+)"\]', txt[txt.index("def _config_text"):txt.index("def _copy_tree")]))
        self.assertTrue(used <= fields, f"الاعدادات التي يقرؤها بايثون ولا يرسلها Kotlin: {used - fields}")

    def test_logfile_prefix_mask_rotation(self):
        ar = self._import_runner()
        d = tempfile.mkdtemp()
        try:
            lf = ar._LogFile(os.path.join(d, "z.log"))
            lf.set_secrets(["SECRETVALUE123", "short"])      # "short" اقصر من 8 → يُتجاهل
            lf.write("hello SECRETVALUE123 x\nline2\n")
            lf.write("partial ")
            lf.write("continues\n")
            lf.flush()
            lines = open(os.path.join(d, "z.log"), encoding="utf-8").read().splitlines()
            self.assertEqual(len(lines), 3)
            for l in lines:
                self.assertRegex(l, r"^\d\d:\d\d:\d\d ")
            self.assertNotIn("SECRETVALUE123", "".join(lines))
            self.assertIn("***", lines[0])
            self.assertEqual(lines[2].count(":"), 2, "الوقت يجب ان يُكتب مرة واحدة لكل سطر")
            big = os.path.join(d, "big.log")
            open(big, "w").write("x" * (600 * 1024))
            ar._LogFile(big)
            self.assertLess(os.path.getsize(big), 1024, "السجل الكبير لم يُدوَّر")
        finally:
            shutil.rmtree(d, ignore_errors=True)


class T04_Assets(unittest.TestCase):
    def test_fonts_load_with_pillow(self):
        try:
            from PIL import ImageFont
        except ImportError:
            self.skipTest("Pillow غير متوفر")
        for f in ("digital.ttf", "impact.ttf"):
            font = ImageFont.truetype(str(PYDIR / "zahid_source" / "styles" / f), 30)
            self.assertIsNotNone(font.getmask("ABC 123"))


# ═════════════════════════ 2) اندرويد ═════════════════════════
def _xmls():
    return sorted(RES.rglob("*.xml")) + [MAIN / "AndroidManifest.xml"]


def _res_names():
    names = {k: set() for k in ("drawable", "color", "string", "style", "layout", "mipmap", "dimen", "id", "xml", "anim", "array", "bool", "integer", "font")}
    for p in RES.rglob("*"):
        if p.is_file():
            t = p.parent.name.split("-")[0]
            if t in names and t != "values":
                names[t].add(p.stem)
    for p in (RES / "values").glob("*.xml"):
        doc = minidom.parse(str(p))
        for el in doc.documentElement.childNodes:
            if el.nodeType == 1 and el.hasAttribute("name"):
                tag = el.tagName
                kind = {"string": "string", "color": "color", "style": "style", "dimen": "dimen", "bool": "bool", "integer": "integer",
                        "string-array": "array", "array": "array", "integer-array": "array", "item": el.getAttribute("type") or "id"}.get(tag)
                if kind:
                    names.setdefault(kind, set()).add(el.getAttribute("name").replace(".", "_"))
                    if kind == "style":
                        names["style"].add(el.getAttribute("name"))
    for p in RES.rglob("layout*/*.xml"):
        names["id"] |= set(re.findall(r'@\+id/(\w+)', p.read_text(encoding="utf-8")))
    return names


class T10_AndroidResources(unittest.TestCase):
    def test_all_xml_well_formed(self):
        for p in _xmls():
            try:
                minidom.parse(str(p))
            except Exception as e:
                self.fail(f"{p.relative_to(MAIN)}: {e}")

    def test_resource_references_exist(self):
        names, bad = _res_names(), []
        for p in _xmls():
            txt = p.read_text(encoding="utf-8")
            for kind, n in re.findall(r"@(?:\+)?(drawable|color|string|style|layout|mipmap|dimen|id|xml|anim|array|bool|integer|font)/([\w.]+)", txt):
                if "@+id/" in txt and kind == "id":
                    pass
                if n.replace(".", "_") not in names.get(kind, set()) and n not in names.get(kind, set()):
                    bad.append(f"{p.name}: @{kind}/{n}")
        self.assertEqual(sorted(set(bad)), [])

    def test_no_duplicate_ids_across_main_screen(self):
        """نفس الـ id في صفحتين مدمجتين = findViewById يرجع العنصر الخطأ."""
        seen, dups = {}, []
        for lay in ("activity_main", "page_home", "page_settings", "page_logs", "page_about"):
            for i in re.findall(r'android:id="@\+id/(\w+)"', (RES / "layout" / f"{lay}.xml").read_text(encoding="utf-8")):
                if i in seen and seen[i] != lay or (i in seen and seen[i] == lay):
                    dups.append(f"{i} ({seen[i]} + {lay})")
                seen[i] = lay
        self.assertEqual(dups, [])

    def test_vector_paths_valid(self):
        arity = dict(M=2, L=2, H=1, V=1, C=6, S=4, Q=4, T=2, A=7, Z=0)
        num = r"[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?"
        bad = []
        for p in (RES / "drawable").glob("*.xml"):
            doc = minidom.parse(str(p))
            if doc.documentElement.tagName != "vector":
                continue
            self.assertTrue(float(doc.documentElement.getAttribute("android:viewportWidth")) > 0, p.name)
            for el in doc.getElementsByTagName("path"):
                d = el.getAttribute("android:pathData")
                toks = re.findall(rf"[MmLlHhVvCcSsQqTtAaZz]|{num}", d)
                self.assertEqual("".join(toks).replace(" ", ""), re.sub(r"[\s,]", "", d).replace(" ", ""), f"{p.name}: رموز غير مفهومة")
                i, cmd = 0, None
                while i < len(toks):
                    if toks[i].isalpha():
                        cmd = toks[i]; i += 1
                        if cmd in "Zz":
                            continue
                    k = arity[cmd.upper()]
                    args = toks[i:i + k]
                    if len(args) < k or any(a.isalpha() for a in args):
                        bad.append(f"{p.name}: '{cmd}' يحتاج {k} ارقام قرب {d[max(0,0):60]}")
                        break
                    i += k
                    if cmd in "Mm":
                        cmd = "L" if cmd == "M" else "l"
        self.assertEqual(bad, [])

    def test_colors_valid_hex(self):
        for m in re.finditer(r'<color name="(\w+)">([^<]+)</color>', (RES / "values" / "colors.xml").read_text(encoding="utf-8")):
            self.assertRegex(m.group(2).strip(), r"^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$", m.group(1))
        for p in RES.rglob("*.xml"):
            for h in re.findall(r'="(#[0-9A-Za-z]+)"', p.read_text(encoding="utf-8")):
                self.assertRegex(h, r"^#([0-9A-Fa-f]{3,4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$", f"{p.name}: {h}")

    def test_layout_direction_values(self):
        for p in (RES / "layout").glob("*.xml"):
            for v in re.findall(r'android:layoutDirection="([^"]+)"', p.read_text(encoding="utf-8")):
                self.assertIn(v, ("ltr", "rtl", "inherit", "locale"), p.name)

    def test_hero_image_present(self):
        from struct import unpack
        data = (RES / "drawable-nodpi" / "hero_art.png").read_bytes()
        self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
        w, h = unpack(">II", data[16:24])
        self.assertGreater(w, 200); self.assertGreater(h, 200)

    def test_layout_direction_and_gravity_attrs(self):
        """start/end + layoutDirection: كل عنصر LTR يجب ان لا يستخدم gravity=right/left داخل أب RTL بالخطأ — نتحقق فقط من القيم المسموحة."""
        ok_grav = {"top", "bottom", "left", "right", "start", "end", "center", "center_vertical", "center_horizontal", "fill", "fill_horizontal", "fill_vertical", "clip_vertical", "clip_horizontal"}
        for p in (RES / "layout").glob("*.xml"):
            for g in re.findall(r'android:(?:layout_)?gravity="([^"]+)"', p.read_text(encoding="utf-8")):
                for part in g.split("|"):
                    self.assertIn(part, ok_grav, f"{p.name}: gravity={g}")


_PARENTS = {
    "View": None, "ViewGroup": "View", "LinearLayout": "ViewGroup", "FrameLayout": "ViewGroup", "RelativeLayout": "ViewGroup",
    "ScrollView": "FrameLayout", "HorizontalScrollView": "FrameLayout", "ConstraintLayout": "ViewGroup", "GridLayout": "ViewGroup",
    "CardView": "FrameLayout", "MaterialCardView": "CardView", "TextView": "View", "EditText": "TextView", "Button": "TextView",
    "CompoundButton": "Button", "Switch": "CompoundButton", "SwitchMaterial": "Switch", "CheckBox": "CompoundButton",
    "MaterialButton": "Button", "TextInputEditText": "EditText", "ImageView": "View", "ImageButton": "ImageView",
    "ProgressBar": "View", "Space": "View", "TextInputLayout": "LinearLayout", "SeekBar": "ProgressBar", "include": "View",
}


def _ancestors(t):
    out = []
    while t:
        out.append(t)
        t = _PARENTS.get(t)
    return set(out)


class T11_KotlinAgainstLayouts(unittest.TestCase):
    def _layout_types(self):
        types = {}
        for p in (RES / "layout").glob("*.xml"):
            doc = minidom.parse(str(p))

            def walk(el):
                for ch in el.childNodes:
                    if ch.nodeType != 1:
                        continue
                    i = ch.getAttribute("android:id")
                    if i.startswith("@+id/"):
                        types.setdefault(i[5:], ch.tagName.split(".")[-1])
                    walk(ch)
            walk(doc.documentElement)
        return types

    def _kt(self):
        return {p.name: p.read_text(encoding="utf-8") for p in KT}

    def test_r_references_exist(self):
        names, bad = _res_names(), []
        for fn, src in self._kt().items():
            for kind, n in re.findall(r"\bR\.(id|layout|drawable|color|string|style|mipmap|dimen|xml|array)\.(\w+)", src):
                if n not in names.get(kind, set()) and n.replace("_", ".") not in names.get(kind, set()):
                    bad.append(f"{fn}: R.{kind}.{n}")
        self.assertEqual(sorted(set(bad)), [])

    def test_findviewbyid_types_match_layout(self):
        """ClassCastException عند التشغيل اذا كتبت findViewById<ImageButton> لعنصر LinearLayout."""
        lay = self._layout_types()
        problems = []
        for fn, src in self._kt().items():
            declared = dict(re.findall(r"(?:lateinit\s+)?(?:private\s+)?va[lr]\s+(\w+)\s*:\s*([\w.<>?, ]+?)\s*(?:=|\n|$)", src))
            for m in re.finditer(r"findViewById(?:<(\w+)>)?\(\s*R\.id\.(\w+)\s*\)", src):
                gen, rid = m.group(1), m.group(2)
                want = gen
                if not want:     # اسم المتغير من يسار "=" في نفس السطر
                    line = src[src.rfind("\n", 0, m.start()) + 1:m.start()]
                    v = re.search(r"(\w+)\s*=\s*$", line)
                    want = declared.get(v.group(1), "").strip() if v else ""
                    want = want.split("<")[0] if want else ""
                if not want or rid not in lay:
                    continue
                have = lay[rid]
                if have not in _PARENTS and have not in ("include",):
                    continue
                if want not in _ancestors(have) and want not in ("View",):
                    problems.append(f"{fn}: R.id.{rid} هو <{have}> لكن الكود يطلبه {want}")
        self.assertEqual(problems, [])

    def test_lateinit_properties_are_assigned(self):
        problems = []
        for fn, src in self._kt().items():
            for name in re.findall(r"lateinit\s+var\s+(\w+)\s*:", src):
                if not re.search(rf"(?<![\w.])(?:this\.)?{name}\s*=(?!=)", src):
                    problems.append(f"{fn}: lateinit {name} لا يُسند ابداً")
        self.assertEqual(problems, [])

    @staticmethod
    def _scan_brackets(src):
        """ماسح Kotlin بسيط: يتجاوز التعليقات والنصوص (ويتتبع ${...} داخل النصوص) ويرجع اول خطأ توازن او None."""
        pairs, stack, i, n, line = {")": "(", "]": "[", "}": "{"}, [], 0, len(src), 1
        tmpl = []          # اعماق الاقواس عند دخول ${ داخل نص
        while i < n:
            c = src[i]
            if c == "\n":
                line += 1
            if src.startswith("//", i):
                i = src.find("\n", i)
                i = n if i < 0 else i
                continue
            if src.startswith("/*", i):
                j = src.find("*/", i + 2)
                line += src.count("\n", i, j if j > 0 else n)
                i = n if j < 0 else j + 2
                continue
            if src.startswith('"""', i):
                j = src.find('"""', i + 3)
                line += src.count("\n", i, j if j > 0 else n)
                i = n if j < 0 else j + 3
                continue
            if c == "'":
                m = re.match(r"'(?:\\.|[^'\\\n])'", src[i:i + 8])
                if m:
                    i += m.end()
                    continue
            if c == '"':
                i += 1
                while i < n and src[i] != '"':
                    if src[i] == "\\":
                        i += 2
                        continue
                    if src.startswith("${", i):       # تعبير داخل النص: نحلله كشيفرة عادية
                        depth, i = 1, i + 2
                        while i < n and depth:
                            if src[i] == "{":
                                depth += 1
                            elif src[i] == "}":
                                depth -= 1
                            elif src[i] == '"':       # نص متداخل
                                k = i + 1
                                while k < n and src[k] != '"':
                                    k += 2 if src[k] == "\\" else 1
                                i = k
                            i += 1
                        continue
                    if src[i] == "\n":
                        line += 1
                    i += 1
                i += 1
                continue
            if c in "([{":
                stack.append((c, line))
            elif c in ")]}":
                if not stack or stack[-1][0] != pairs[c]:
                    return f"'{c}' زائد عند السطر {line}"
                stack.pop()
            i += 1
        if stack:
            return f"'{stack[-1][0]}' غير مغلق (فُتح عند السطر {stack[-1][1]})"
        return None

    def test_brackets_balanced(self):
        for fn, src in self._kt().items():
            self.assertIsNone(self._scan_brackets(src), fn)

    def test_removed_members_not_referenced(self):
        """اعضاء حذفناها في التصميم الجديد يجب ان لا يبقى لها استخدام."""
        gone = ["btnStart", "btnStop", "tvSumService", "tvSumLastOp", "tvSumUpdated", "navsTop", "topTabs", "tabHome"]
        for fn, src in self._kt().items():
            for g in gone:
                self.assertNotRegex(src, rf"\b{g}\b", f"{fn} ما زال يستخدم {g}")

    def test_every_clickable_id_in_home_is_wired(self):
        src = "".join(self._kt().values())
        for i in ("statusBot", "btnHomeLogClear", "cardAppInfo", "btnMenu", "navHome", "navSettings", "navLogs", "navAbout",
                  "tilePerms", "tileAccount", "tileOptions", "tileBot", "tileSession", "tvHomeLog", "tvHomeVersion", "headerBlock"):
            self.assertIn(f"R.id.{i}", src, f"{i} موجود في التخطيط ولا يُربط في الكود")

    def test_single_tab_bar(self):
        lay = (RES / "layout" / "activity_main.xml").read_text(encoding="utf-8")
        self.assertEqual(lay.count('android:id="@+id/navBar"'), 1)
        self.assertNotIn("topTabs", lay)
        for t in ("navHome", "navSettings", "navLogs", "navAbout"):
            self.assertEqual(lay.count(f'@+id/{t}"'), 1, t)
        # الشريط آخر عنصر في الشاشة (اسفل)
        self.assertGreater(lay.index("@+id/navBar"), lay.index("@+id/pages"))


class T12_Manifest(unittest.TestCase):
    def setUp(self):
        self.mf = (MAIN / "AndroidManifest.xml").read_text(encoding="utf-8")
        self.kt = "".join(p.read_text(encoding="utf-8") for p in KT)

    def test_components_have_classes(self):
        for n in re.findall(r'<(?:activity|service|receiver)[^>]*android:name="\.(\w+)"', self.mf):
            self.assertRegex(self.kt, rf"class\s+{n}\b", n)

    def test_exported_declared_for_intent_filters(self):
        doc = minidom.parseString(self.mf.encode())
        for tag in ("activity", "service", "receiver"):
            for el in doc.getElementsByTagName(tag):
                if el.getElementsByTagName("intent-filter"):
                    self.assertTrue(el.hasAttribute("android:exported"), el.getAttribute("android:name"))

    def test_foreground_service_type_and_permission(self):
        """Android 14: نوع الخدمة + صلاحية FOREGROUND_SERVICE_<TYPE> وإلا ينهار startForeground."""
        self.assertIn('android:foregroundServiceType="specialUse"', self.mf)
        self.assertIn("FOREGROUND_SERVICE_SPECIAL_USE", self.mf)
        self.assertIn("PROPERTY_SPECIAL_USE_FGS_SUBTYPE", self.mf)
        self.assertIn("android.permission.FOREGROUND_SERVICE\"", self.mf)

    def test_permissions_used_in_code_are_declared(self):
        need = {"Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS": "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
                "POWER_SERVICE": "WAKE_LOCK", "POST_NOTIFICATIONS": "POST_NOTIFICATIONS", "BOOT_COMPLETED": "RECEIVE_BOOT_COMPLETED"}
        for token, perm in need.items():
            if token in self.kt or token in self.mf:
                self.assertIn(f"android.permission.{perm}", self.mf, perm)

    def test_boot_receiver_does_not_crash_without_config(self):
        src = (MAIN / "java" / "com" / "zahid" / "bot" / "BootReceiver.kt").read_text(encoding="utf-8")
        self.assertIn("BOOT_COMPLETED", src)

    def test_main_activity_theme_and_strings(self):
        names = _res_names()
        self.assertIn("app_name", names["string"])
        self.assertIn("Theme.ZahidBot", names["style"])


class T13_BuildFiles(unittest.TestCase):
    def test_workflow_builds_apk(self):
        wf = (ROOT / ".github" / "workflows" / "build-apk.yml").read_text(encoding="utf-8")
        for token in ("assembleDebug", "setup-java", "upload-artifact", "workflow_dispatch"):
            self.assertIn(token, wf)

    def test_gradle_abi_and_sdk(self):
        g = (ROOT / "app" / "build.gradle.kts").read_text(encoding="utf-8")
        self.assertIn("arm64-v8a", g)
        self.assertRegex(g, r"minSdk\s*=\s*2[6-9]|minSdk\s*=\s*3\d")

    def test_gitignore(self):
        self.assertTrue((ROOT / ".gitignore").is_file())


if __name__ == "__main__":
    unittest.main(verbosity=2)
